from datetime import date
from decimal import Decimal  # 🔹 EKLE
from sqlalchemy import (
    Column, Integer, String, Date, Time, DateTime,
    ForeignKey, Boolean, Table, Float, Numeric, func, Text ,UniqueConstraint, CheckConstraint , Index
)
from sqlalchemy.orm import relationship
from database import Base
# ============================================================
# === ISSUE TAKİP SİSTEMİ
# ============================================================

class Issue(Base):
    __tablename__ = "issues"

    id = Column(Integer, primary_key=True, index=True)
    konu = Column(String, nullable=False)
    aciklama = Column(String)
    modul = Column(String)
    durum = Column(String, default="Kayıt Açık")
    ilgili = Column(String)
    oncelik = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    comments = relationship("Comment", back_populates="issue", cascade="all, delete-orphan")


class Comment(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True, index=True)
    issue_id = Column(Integer, ForeignKey("issues.id"), nullable=False)
    text = Column(String, nullable=False)
    durum = Column(String, default="Kayıt Açık")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    issue = relationship("Issue", back_populates="comments")


# ============================================================
# === KULLANICI & YETKİLENDİRME
# ============================================================

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    personel_code = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    phone = Column(String)
    title = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    department_id = Column(Integer, ForeignKey("Departmanlar.id"))
    unvan_id = Column(Integer, ForeignKey("UnvanTanımları.id"))

    department = relationship("Departman", back_populates="users")
    unvan = relationship("Unvan", back_populates="users")

    unvan_groups = relationship("UserUnvanGroup", back_populates="user")
    rezervasyonlar = relationship("Rezervasyon", back_populates="ilgili")


class Unvan(Base):
    __tablename__ = "UnvanTanımları"

    id = Column(Integer, primary_key=True, index=True)
    ad = Column(String, unique=True, nullable=False)
    aktif = Column(Boolean, default=True)

    users = relationship("User", back_populates="unvan")
    permissions = relationship("Permission", back_populates="unvan", cascade="all, delete")


class Permission(Base):
    __tablename__ = "permissions"

    id = Column(Integer, primary_key=True, index=True)
    module = Column(String)
    action = Column(String)
    unvan_id = Column(Integer, ForeignKey("UnvanTanımları.id"))

    unvan = relationship("Unvan", back_populates="permissions")


class UnvanGroup(Base):
    __tablename__ = "unvan_groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True)
    description = Column(String)

    unvanlar = relationship("Unvan", secondary="unvan_group_unvanlar", backref="groups")


unvan_group_unvanlar = Table(
    "unvan_group_unvanlar",
    Base.metadata,
    Column("unvan_group_id", Integer, ForeignKey("unvan_groups.id")),
    Column("unvan_id", Integer, ForeignKey("UnvanTanımları.id")),
)


class UserUnvanGroup(Base):
    __tablename__ = "user_unvan_groups"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    unvan_group_id = Column(Integer, ForeignKey("unvan_groups.id"))

    unvan_group = relationship("UnvanGroup")
    user = relationship("User", back_populates="unvan_groups")


# ============================================================
# === REZERVASYON SİSTEMİ
# ============================================================

class Rezervasyon(Base):
    __tablename__ = "rezervasyonlar"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    musteri = Column(String, nullable=False)
    hizmet = Column(String, nullable=False)
    tarih = Column(Date, nullable=False)
    saat = Column(Time, nullable=False)
    not_ = Column(String)
    durum = Column(String, default="Açık")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    ilgili_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    ilgili = relationship("User", back_populates="rezervasyonlar")


# ============================================================
# === PROJE - PLAN YÖNETİMİ
# ============================================================

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    proje_adi = Column(String, nullable=False)
    musteri = Column(String)
    baslangic = Column(Date, nullable=False)
    aciklama = Column(String)
    tamamlandi = Column(Boolean, default=False)

    plans = relationship("Plan", back_populates="project", cascade="all, delete-orphan")


class Plan(Base):
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    ad = Column(String, nullable=False)
    sorumlu = Column(String, nullable=False)
    calisma_sekli = Column(String, nullable=False)
    baslangic = Column(DateTime, nullable=False)
    bitis = Column(DateTime, nullable=False)
    aciklama = Column(String)
    olusturma = Column(DateTime(timezone=True), server_default=func.now())

    proje_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    project = relationship("Project", back_populates="plans")

    alan_id = Column(Integer, ForeignKey("alanlar.id"), nullable=True)
    alan = relationship("Alan")


# ============================================================
# === ALAN & HİZMET TÜRÜ
# ============================================================

class Alan(Base):
    __tablename__ = "alanlar"

    id = Column(Integer, primary_key=True, index=True)
    ad = Column(String, nullable=False, unique=True)
    aktif = Column(Boolean, default=True)


class HizmetTuru(Base):
    __tablename__ = "hizmet_turleri"

    id = Column(Integer, primary_key=True, index=True)
    ad = Column(String, nullable=False, unique=True)
    aktif = Column(Boolean, default=True)



# ============================================================
# === DEPARTMAN
# ============================================================

class Departman(Base):
    __tablename__ = "Departmanlar"

    id = Column(Integer, primary_key=True, index=True)
    ad = Column(String, unique=True, nullable=False)
    aktif = Column(Boolean, default=True)

    users = relationship("User", back_populates="department")
# ============================================================
# === CARİ HESAPLAR
# ============================================================
class Cari(Base):
    __tablename__ = "cariler"
    __table_args__ = (
        UniqueConstraint("hesap_kodu", name="uq_cari_hesap_kodu"),
        UniqueConstraint("belge_no", name="uq_cari_belge_no"),
        Index("ix_cari_unvan", "unvan"),
        Index("ix_cari_hesap_turu", "hesap_turu"),
    )

    id = Column(Integer, primary_key=True, index=True)

    # Kimlik / Tür
    hesap_tipi = Column(String, nullable=False)      # bireysel / kurumsal
    hesap_turu = Column(String, nullable=True)       # musteri / tedarikci / potansiyel
    hesap_kodu = Column(String, nullable=True, unique=True)

    # Temel bilgiler
    unvan = Column(String, nullable=False)
    telefon = Column(String, nullable=True)
    email = Column(String, nullable=True)
    vergi_no = Column(String, nullable=True)         # bireysel: TCKN (11), kurumsal: VKN (10)
    vergi_dairesi = Column(String, nullable=True)

    # Adres
    adres = Column(String, nullable=True)
    posta_kodu = Column(String, nullable=True)
    ilce = Column(String, nullable=True)
    il = Column(String, nullable=True)
    ulke = Column(String, nullable=True)

    # Diğer
    doviz_turu = Column(String, nullable=True)
    aciklama = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    satis_kanali = Column(String, nullable=True)
    hesap_grubu = Column(String, nullable=True)
    sektor = Column(String, nullable=True)

    # Belge bilgileri
    belge_tipi = Column(String, nullable=False, default="Cari Açılışı")  # <-- eklendi
    belge_seri = Column(String(2), nullable=False)
    belge_no   = Column(String(100), nullable=False, unique=True)

    # Finans / muhasebe
    tahsilat_gunu   = Column(String, nullable=True)     # örn: "Pazartesi"
    tahsilat_vadesi = Column(String, nullable=True)     # örn: "Net 30"
    tahsilat_plani  = Column(String, nullable=True)
    muhasebe_hesabi = Column(String, nullable=True)

    # İlişkiler
    islemler = relationship(
        "CariIslem",
        back_populates="cari",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


# ============================================================
# === CARİ İŞLEMLER
# ============================================================
class CariIslem(Base):
    __tablename__ = "cari_islemler"
    __table_args__ = (
        UniqueConstraint("belge_no", name="uq_cariislem_belge_no"),
        Index("ix_cariislem_tarih", "tarih"),
    )

    id = Column(Integer, primary_key=True, index=True)

    # Bağlantılar
    cari_id = Column(Integer, ForeignKey("cariler.id", ondelete="CASCADE"), nullable=False)
    virman_id = Column(Integer, ForeignKey("virman_islemler.id", ondelete="SET NULL"), nullable=True)

    # Belge ve tarih
    tarih = Column(Date, nullable=False)
    aciklama = Column(String, nullable=True)
    belge_tipi = Column(String, nullable=True)  # <<< EKLENDİ
    belge_seri = Column(String(2), nullable=False)
    belge_no   = Column(String(100), nullable=False, unique=True)

    # Tutarlar (para alanları için Numeric tercih ettik)
    borc   = Column(Numeric(18, 2), default=0)
    alacak = Column(Numeric(18, 2), default=0)
    bakiye = Column(Numeric(18, 2), default=0)

    # Ek alanlar
    hesap_kodu = Column(String, nullable=True)  # referans amaçlı
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # İlişkiler
    cari = relationship("Cari", back_populates="islemler")
    # Not: VirmanIslem tarafında back_populates tanımlıysa burada da ekleyebilirsin:
    # virman = relationship("VirmanIslem", back_populates="cari_islemler")

    
    
# ============================================================
# === DÖVİZ KURLARI
# ============================================================

class DovizKur(Base):
    __tablename__ = "doviz_kurlari"

    id = Column(Integer, primary_key=True, index=True)
    kod = Column(String, index=True)               # USD, EUR, TRY vb.
    tarih = Column(Date, index=True)              # Kurun geçerli olduğu gün
    alis = Column(String)                         # ForexBuying veya TCMB alış kuru
    satis = Column(String)                        # ForexSelling veya TCMB satış kuru
    kaynak = Column(String, default="TCMB")       # Kaynak: TCMB, ECB, API vs.
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    efektif_alis = Column(String, nullable=True)
    efektif_satis = Column(String, nullable=True)
# ============================================================
# === Ekstre
# ============================================================
class Ekstre(Base):
    __tablename__ = "ekstre"

    id = Column(Integer, primary_key=True, index=True)
    kaynak_tipi = Column(String, index=True)  # Örn: "cari", "stok"
    kaynak_id = Column(Integer, index=True)   # İlgili kaynağın ID'si
    tarih = Column(Date)
    aciklama = Column(String)
    borc = Column(Float, default=0)
    alacak = Column(Float, default=0)
    bakiye = Column(Float, default=0)



# ===========================
# FİNANS KASA / BANKA
# ===========================
from datetime import date
from decimal import Decimal
from sqlalchemy import (
    Column, Integer, String, Date, DateTime, ForeignKey, Boolean, Text, Numeric,
    CheckConstraint, Index, UniqueConstraint, func
)
from sqlalchemy.orm import relationship
from database import Base


# ===========================
# FİNANS KASA / BANKA KARTI
# ===========================
class Kasa(Base):
    __tablename__ = "finans_kasalar"

    id   = Column(Integer, primary_key=True, index=True)
    kod  = Column(String(50), index=True, nullable=False)        # ❌ unique kaldırıldı
    ad   = Column(String(200), nullable=False)

    tur     = Column(String(20), nullable=False)                  # 'Kasa' / 'Banka'
    alt_tur = Column(String(50), nullable=True)

    doviz = Column(String(10), nullable=False, default="TRY")

    # Banka bilgileri (Kasa ise boş gönderilir/gösterilmez)
    banka_adi = Column(String(200), nullable=True)
    iban      = Column(String(34),  nullable=True)

    aciklama  = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)

    # Muhasebe bağlantısı (opsiyonel)
    hesap_plani_id = Column(Integer, ForeignKey("hesap_plani.id"), nullable=True, index=True)
    hesap_plani    = relationship("HesapPlani", lazy="joined")

    # Karttaki belge alanları (tam no string)
    belge_tipi = Column(String(80), nullable=False)
    belge_seri = Column(String(2),  nullable=False)
    belge_no   = Column(String(100), nullable=False)              # ❌ unique değil

    # Açılış bilgilerinin kart üstünde saklanan kopyası
    acilis_tutari = Column(Numeric(18, 2), nullable=False, default=Decimal("0"))
    acilis_yonu   = Column(String(5),      nullable=False, default="Borç")  # 'Borç'/'Alacak'
    acilis_tarih  = Column(Date,           nullable=False, server_default=func.current_date())

    islemler = relationship(
        "KasaIslem",
        back_populates="kasa",
        cascade="all, delete-orphan",
        passive_deletes=False,
    )

    __table_args__ = (
        CheckConstraint("tur in ('Kasa','Banka')", name="ck_kasa_tur"),
        CheckConstraint("acilis_yonu in ('Borç','Alacak')", name="ck_kasa_yon"),
        Index("ix_kasa_tur_doviz", "tur", "doviz"),
    )

class KasaIslem(Base):
    __tablename__ = "finans_islemler"

    id = Column(Integer, primary_key=True, index=True)

    kasa_id        = Column(Integer, ForeignKey("finans_kasalar.id"), nullable=False, index=True)
    hesap_plani_id = Column(Integer, ForeignKey("hesap_plani.id"),    nullable=True,  index=True)

    tarih    = Column(Date, nullable=False, server_default=func.current_date())
    aciklama = Column(String(255), nullable=True)

    # Belge bilgisi (numaratör)
    belge_tipi = Column(String(80), nullable=False)
    belge_seri = Column(String(2),  nullable=False)
    belge_no   = Column(Integer,    nullable=False)                 # sayısal sayaç

    doviz_turu = Column(String(10), nullable=False, default="TRY")
    kur        = Column(Numeric(18, 6), nullable=False, default=Decimal("1"))

    borc   = Column(Numeric(18, 2), nullable=False, default=Decimal("0"))
    alacak = Column(Numeric(18, 2), nullable=False, default=Decimal("0"))
    bakiye = Column(Numeric(18, 2), nullable=False, default=Decimal("0"))

    hesap_kodu = Column(String(50), nullable=True)
    virman_id  = Column(Integer, ForeignKey("virman_islemler.id"), nullable=True, index=True)

    referans_tablo = Column(String(50), nullable=True)
    referans_id    = Column(Integer,    nullable=True)

    kasa         = relationship("Kasa",       back_populates="islemler", lazy="joined")
    hesap_plani  = relationship("HesapPlani", lazy="joined")

    __table_args__ = (
        Index("ix_kasaislem_belge", "belge_seri", "belge_no"),
        Index("ix_kasaislem_tarih", "tarih", "id"),
        Index("ix_kasaislem_kasa_tarih", "kasa_id", "tarih"),
        CheckConstraint("borc >= 0",   name="ck_kasaislem_borc_nonneg"),
        CheckConstraint("alacak >= 0", name="ck_kasaislem_alacak_nonneg"),
        # İstersen açarsın:
        # UniqueConstraint("belge_seri","belge_no", name="uq_kasaislem_seri_no"),
    )

# Eski adlarla uyumluluk (başka modüller kırılmasın)
FinansKasa  = Kasa
FinansIslem = KasaIslem


# === HESAP PLANI ANA TABLO ===
class HesapPlani(Base):
    __tablename__ = "hesap_plani"

    id = Column(Integer, primary_key=True, index=True)
    kod = Column(String, unique=True, index=True, nullable=False)  # ✅ Aynı kodla eşleşme yapılır
    ad = Column(String, nullable=False)

    hesap_tipi = Column(String, nullable=True)
    bilanco_tipi = Column(String, nullable=True)
    doviz_turu = Column(String, default="TRY")
    kur_turu = Column(String, nullable=True)

    ana_hesap = Column(Boolean, default=False)
    ust_hesap_kodu = Column(String, ForeignKey("hesap_plani.kod"), nullable=True)
    grup = Column(String, nullable=True)
    fislerde_kullanilabilir = Column(Boolean, default=True)
    aktif = Column(Boolean, default=True)
    aciklama = Column(Text, nullable=True)
    belge_seri = Column(String(2), nullable=False)
    belge_no   = Column(String(100), nullable=False, unique=True)
    # 🔗 Hareketler
    islemler = relationship("HesapPlaniIslem", backref="hesap", cascade="all, delete-orphan")


# === HESAP PLANI İŞLEMLERİ ===
class HesapPlaniIslem(Base):
    __tablename__ = "hesap_plani_islemler"

    id = Column(Integer, primary_key=True, index=True)
    hesap_id = Column(Integer, ForeignKey("hesap_plani.id"), nullable=False)

    tarih = Column(Date, nullable=False)
    aciklama = Column(String, nullable=True)

    belge_seri = Column(String(2), nullable=False)
    belge_no   = Column(String(100), nullable=False, unique=True)

    borc = Column(Float, default=0)
    alacak = Column(Float, default=0)
    bakiye = Column(Float, default=0)
    hesap_kodu = Column(String, nullable=True)  # 👈 yeni
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    virman_id = Column(Integer, ForeignKey("virman_islemler.id"), nullable=True)
# === Ödeme Vadesi === (İKİNCİ TANIM)
class OdemeVadesi(Base):
    __tablename__ = "odeme_vadeleri"
    id = Column(Integer, primary_key=True, index=True)

    kod = Column(String(3), nullable=False, unique=True)  # ✅ YENİ EKLENDİ
    ad = Column(String(50), nullable=False, unique=True)
    gun_sayisi = Column(Integer, nullable=False)
    aktif = Column(Boolean, default=True)

# === finansman === 


class BelgeSeri(Base):
    __tablename__ = "belge_serileri"

    id = Column(Integer, primary_key=True)
    modul = Column(String(50), nullable=False)          # "Cari","Finansman","Stok","Satis"...
    belge_tipi = Column(String(100), nullable=False)    # "Virman","Hesap Planı Açılışı",...
    alan_id = Column(Integer, ForeignKey("alanlar.id"), nullable=True)
    seri_kodu = Column(String(2), nullable=False)       # 2 hane şart
    pad_length = Column(Integer, nullable=False, default=6)
    prefix = Column(String(20))
    suffix = Column(String(20))
    yil_bazli = Column(Boolean, nullable=False, default=True)
    ay_bazli  = Column(Boolean, nullable=False, default=False)

    son_yil = Column(Integer)
    son_ay  = Column(Integer)
    sayac   = Column(Integer, nullable=False, default=0)

    aktif = Column(Boolean, nullable=False, default=True)
    aciklama = Column(Text)

    __table_args__ = (
        UniqueConstraint("modul","belge_tipi","alan_id", name="uq_belgeseri_scope"),
        CheckConstraint("char_length(seri_kodu) = 2", name="ck_seri_2char"),
    )
