
from fastapi import APIRouter
from datetime import datetime, timedelta

router = APIRouter(prefix="/stats", tags=["İstatistikler"])

@router.get("/status-counts")
def get_status_counts():
    return {
        "Kayıt Açık": 14,
        "Tamamlandı": 22,
        "İnceleniyor": 7,
        "İşlemde": 5,
        "Beklemede": 3
    }

@router.get("/daily-created")
def get_daily_created():
    today = datetime.today()
    return [
        {"date": (today - timedelta(days=i)).strftime("%Y-%m-%d"), "count": i % 5 + 1}
        for i in range(7)
    ]

@router.get("/monthly-created")
def get_monthly_created():
    return [
        {"month": f"2024-{str(i).zfill(2)}", "count": (i * 3) % 12 + 1}
        for i in range(1, 13)
    ]

@router.get("/closing-rate")
def get_closing_rate():
    return {"rate": 82}

@router.get("/avg-open-days")
def get_avg_open_days():
    return {"average_days": 4.2}

@router.get("/top-users")
def get_top_users():
    return [
        {"name": "Ali", "count": 18},
        {"name": "Zeynep", "count": 14},
        {"name": "Mehmet", "count": 11}
    ]
