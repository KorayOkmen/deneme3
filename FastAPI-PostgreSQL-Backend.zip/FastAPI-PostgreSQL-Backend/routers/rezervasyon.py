from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import schemas
import crud

router = APIRouter(
    prefix="/rezervasyonlar",
    tags=["Rezervasyon"]
)

# ✅ Rezervasyon Oluşturma
@router.post("/", response_model=schemas.RezervasyonOut)
def rezervasyon_ekle(rezervasyon: schemas.RezervasyonCreate, db: Session = Depends(get_db)):
    print("🔍 Gelen rezervasyon verisi:", rezervasyon.dict())
    return crud.create_rezervasyon(db, rezervasyon, rezervasyon.force)

# ✅ Tüm rezervasyonları listele
@router.get("/", response_model=list[schemas.RezervasyonOut])
def rezervasyonlari_getir(db: Session = Depends(get_db)):
    return crud.get_rezervasyonlar(db)

# ✅ Tek rezervasyon getir (ID ile)
@router.get("/{rezervasyon_id}", response_model=schemas.RezervasyonOut)
def rezervasyon_getir(rezervasyon_id: int, db: Session = Depends(get_db)):
    rezervasyon = crud.get_rezervasyon_by_id(db, rezervasyon_id)
    if rezervasyon is None:
        raise HTTPException(status_code=404, detail="Rezervasyon bulunamadı")
    return rezervasyon

# ✅ Rezervasyon sil
@router.delete("/{rezervasyon_id}")
def rezervasyon_sil(rezervasyon_id: int, db: Session = Depends(get_db)):
    silindi = crud.delete_rezervasyon(db, rezervasyon_id)
    if not silindi:
        raise HTTPException(status_code=404, detail="Silinecek rezervasyon bulunamadı")
    return {"detail": "Rezervasyon silindi"}

# ✅ Rezervasyon durum güncelle - JSON body ile
@router.patch("/{rezervasyon_id}/durum", response_model=schemas.RezervasyonOut)
def rezervasyon_durum_guncelle(
    rezervasyon_id: int,
    payload: schemas.DurumGuncelle,
    db: Session = Depends(get_db)
):
    sonuc = crud.update_rezervasyon_durum(db, rezervasyon_id, payload.yeni_durum)
    if not sonuc:
        raise HTTPException(status_code=404, detail="Rezervasyon bulunamadı")
    return sonuc
