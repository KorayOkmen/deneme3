from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

import models, schemas
from database import get_db

router = APIRouter()


# === 1. Tüm projeleri getir
@router.get("/", response_model=List[schemas.ProjectOut])
def get_all_projects(db: Session = Depends(get_db)):
    return db.query(models.Project).order_by(models.Project.id.desc()).all()


# === 2. Yeni proje oluştur
@router.post("/", response_model=schemas.ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: schemas.ProjectCreate, db: Session = Depends(get_db)):
    proje = models.Project(**payload.dict())
    db.add(proje)
    db.commit()
    db.refresh(proje)
    return proje


# === 3. Tekil proje bilgisi
@router.get("/{project_id}", response_model=schemas.ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    proje = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not proje:
        raise HTTPException(status_code=404, detail="Proje bulunamadı")
    return proje


# === 4. Projeyi tamamla
@router.put("/{project_id}/complete", response_model=schemas.ProjectOut)
def complete_project(project_id: int, db: Session = Depends(get_db)):
    proje = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not proje:
        raise HTTPException(status_code=404, detail="Proje bulunamadı")

    proje.tamamlandi = True
    db.commit()
    db.refresh(proje)
    return proje


# === 5. Projeyi sil
@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: int, db: Session = Depends(get_db)):
    proje = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not proje:
        raise HTTPException(status_code=404, detail="Proje bulunamadı")

    db.delete(proje)
    db.commit()
