from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from database import SessionLocal
from models import User
import schemas, crud
from passlib.context import CryptContext
from sqlalchemy import desc

router = APIRouter(
    prefix="/users",
    tags=["Users"]
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ============================================================
# === Personel Kodu Üret
# ============================================================
@router.get("/next-code", response_model=dict)
def get_next_personel_code(db: Session = Depends(get_db)):
    users = db.query(User).filter(User.personel_code.like("PR%"))

    max_number = 0
    for user in users:
        code = user.personel_code
        if code and code.startswith("PR"):
            try:
                number = int(code[2:])
                if number > max_number:
                    max_number = number
            except ValueError:
                continue

    next_number = max_number + 1
    next_code = f"PR{next_number:05d}"
    return {"next_code": next_code}

# ============================================================
# === Kullanıcı İşlemleri
# ============================================================
@router.post("/", response_model=dict)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Bu e-posta adresi zaten kayıtlı")

    try:
        created_user = crud.create_user(db, user)
        return {"message": "Kullanıcı oluşturuldu", "user_id": created_user.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/", response_model=list[schemas.UserOut])
def get_users(db: Session = Depends(get_db)):
    return db.query(User).all()

@router.get("/{user_id}", response_model=schemas.UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    return user

@router.delete("/{user_id}", response_model=dict)
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    db.delete(user)
    db.commit()
    return {"message": "Kullanıcı silindi"}

@router.put("/{user_id}/change-password", response_model=dict)
def change_password(
    user_id: int,
    new_password: str = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    user.hashed_password = pwd_context.hash(new_password)
    db.commit()
    return {"message": "Şifre başarıyla güncellendi"}

@router.put("/{user_id}/status", response_model=dict)
def update_user_status(
    user_id: int,
    is_active: bool = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    user.is_active = is_active
    db.commit()
    return {"message": "Kullanıcı durumu güncellendi"}

@router.put("/{user_id}", response_model=dict)
def update_user(
    user_id: int,
    updated_data: schemas.UserUpdate,
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    for field, value in updated_data.dict(exclude_unset=True).items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return {"message": "Kullanıcı bilgileri güncellendi"}