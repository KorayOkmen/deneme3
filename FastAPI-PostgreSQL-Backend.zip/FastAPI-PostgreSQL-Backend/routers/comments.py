from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from database import get_db
import models, schemas
import shutil
import os
from datetime import datetime

router = APIRouter(prefix="/comments", tags=["Comments"])

UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/", response_model=schemas.CommentOut)
def create_comment(comment: schemas.CommentCreate, db: Session = Depends(get_db)):
    issue = db.query(models.Issue).filter(models.Issue.id == comment.issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")

    # Gelen yorumun durumuna göre issue güncelleniyor
    allowed_statuses = [
        "Kayıt Açık", "İnceleniyor", "İşlemde", "Beklemede",
        "Tamamlandı", "Reddedildi", "İptal Edildi", "Kayıt Kapalı"
    ]

    if comment.durum in allowed_statuses:
        issue.durum = comment.durum

    db_comment = models.Comment(
        issue_id=comment.issue_id,
        text=comment.text,
        durum=comment.durum,
    )

    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment



@router.post("/{comment_id}/upload")
def upload_comment_file(comment_id: int, uploaded_file: UploadFile = File(...), db: Session = Depends(get_db)):
    comment = db.query(models.Comment).filter(models.Comment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="Yorum bulunamadı")

    file_ext = uploaded_file.filename.split(".")[-1]
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    saved_filename = f"{comment_id}_{timestamp}.{file_ext}"
    file_path = os.path.join(UPLOAD_DIR, saved_filename)

    with open(file_path, "wb") as f:
        shutil.copyfileobj(uploaded_file.file, f)

    db_file = models.CommentFile(
        comment_id=comment_id,
        filename=uploaded_file.filename,
        filepath=file_path,
    )
    db.add(db_file)
    db.commit()
    db.refresh(db_file)

    return {"filename": uploaded_file.filename, "stored_as": saved_filename}
