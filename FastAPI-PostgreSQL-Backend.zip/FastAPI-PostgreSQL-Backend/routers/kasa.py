from __future__ import annotations
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from database import get_db
import models, schemas

router = APIRouter(prefix="/kasalar", tags=["Kasalar"])

# -------------------------------------------------------------------
# Yardımcılar
# -------------------------------------------------------------------
def _normalize_kod(s: Optional[str]) -> str:
    k = (s or "").strip()
    if not k:
        raise HTTPException(status_code=422, detail="Kod zorunlu.")
    return k

def _norm_doviz(d: Optional[str]) -> str:
    s = (d or "TRY").strip().upper()
    return "TRY" if s in ("TL", "TRY") else s

def _belge_seri_var(db: Session, modul: str, belge_tipi: str, alan_id: Optional[int]) -> bool:
    return db.query(models.BelgeSeri).filter_by(
        modul=modul, belge_tipi=belge_tipi, alan_id=alan_id
    ).first() is not None

def _get_number(db: Session, modul: str, belge_tipi: str, alan_id: int | None = None) -> Tuple[str, int, str]:
    """Numaratörden (belge_seri, belge_no_int, full_no_string) döndürür."""
    from services.numarator import get_next_number
    res = get_next_number(db, modul=modul, belge_tipi=belge_tipi, alan_id=alan_id)

    if isinstance(res, dict):
        seri = str(res.get("belge_seri") or res.get("seri") or "")
        sayi = int(res.get("belge_no") or res.get("sayi") or 0)
        full = str(res.get("full_no") or f"{seri}-{str(sayi).zfill(6)}")
        return seri, sayi, full

    if isinstance(res, (tuple, list)) and len(res) >= 3:
        seri, full, sayi = str(res[0]), str(res[1]), int(res[2])
        return seri, sayi, full

    raise RuntimeError("Numaratör beklenen formatta dönmedi.")

def _full_no_kullaniliyor_mu(db: Session, full_no: str) -> bool:
    if db.query(models.HesapPlaniIslem.id).filter(models.HesapPlaniIslem.belge_no == full_no).first():
        return True
    if db.query(models.CariIslem.id).filter(models.CariIslem.belge_no == full_no).first():
        return True
    return False

def _resolve_belge_tipi(kasa: schemas.KasaCreate) -> str:
    if kasa.tur == "Kasa":
        return "Kasa Açılışı"
    if kasa.tur == "Banka":
        mapping = {
            "Kredi": "Banka Kredi Açılışı",
            "Borç Çeki": "Borç Çeki Açılışı",
            "Alacak Çeki": "Alacak Çeki Açılışı",
            "Borç Senedi": "Borç Senedi Açılışı",
            "Alacak Senedi": "Alacak Senedi Açılışı",
        }
        return mapping.get(kasa.alt_tur or "", "Banka Açılışı")
    return "Finansman Açılışı"

def _parse_decimal(v) -> Decimal:
    if v is None or v == "":
        return Decimal("0")
    if isinstance(v, (int, float, Decimal)):
        return Decimal(str(v))
    s = str(v).strip().replace(".", "").replace(",", ".")
    try:
        return Decimal(s)
    except (InvalidOperation, ValueError):
        raise HTTPException(status_code=422, detail="Geçersiz tutar.")

def _normalize_yon(v: Optional[str]) -> str:
    s = (v or "").strip().lower()
    if s in ("borç", "borc", "b", "borçlu"):
        return "Borç"
    if s in ("alacak", "a", "alacaklı"):
        return "Alacak"
    return "Borç"

def _insert_finans_islem(
    db: Session,
    *,
    kasa_obj: models.Kasa,
    belge_tipi: str,
    belge_seri: str,
    belge_no_int: int,
    acilis_tutari: Decimal,
    acilis_yonu: str,
    acilis_tarih: date,
    aciklama: str,
):
    is_borc = acilis_yonu == "Borç"
    borc = acilis_tutari if is_borc else Decimal("0")
    alacak = acilis_tutari if not is_borc else Decimal("0")
    bakiye = borc - alacak

    db.add(models.FinansIslem(
        kasa_id=kasa_obj.id,
        hesap_plani_id=getattr(kasa_obj, "hesap_plani_id", None),
        tarih=acilis_tarih,
        aciklama=aciklama,
        belge_tipi=belge_tipi,
        belge_seri=belge_seri,
        belge_no=belge_no_int,      # INT sayaç
        doviz_turu=_norm_doviz(getattr(kasa_obj, "doviz", "TRY")),
        kur=Decimal("1"),
        borc=borc,
        alacak=alacak,
        bakiye=bakiye,
    ))

def _resolve_hesap_plani(db: Session, kasa_obj: models.Kasa):
    """Önce hesap_plani_id ile, yoksa kasa kodu ile HesapPlani bul."""
    hp = None
    hp_id = getattr(kasa_obj, "hesap_plani_id", None)
    if hp_id:
        hp = db.query(models.HesapPlani).get(hp_id)
    if not hp:
        hp = db.query(models.HesapPlani).filter_by(kod=kasa_obj.kod).first()
    return hp

# -------------------------------------------------------------------
# Liste
# -------------------------------------------------------------------
@router.get("/", response_model=list[schemas.KasaOut])
def list_kasalar(
    ad: Optional[str] = Query(None),
    tur: Optional[str] = Query(None),
    alt_tur: Optional[str] = Query(None),
    doviz: Optional[str] = Query(None),
    is_active: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    q = db.query(models.Kasa)
    if ad:
        q = q.filter(models.Kasa.ad.ilike(f"%{ad}%"))
    if tur:
        q = q.filter(models.Kasa.tur == tur)
    if alt_tur:
        q = q.filter(models.Kasa.alt_tur.ilike(f"%{alt_tur}%"))
    if doviz:
        q = q.filter(models.Kasa.doviz == _norm_doviz(doviz))
    if is_active in ("true", "false"):
        q = q.filter(models.Kasa.is_active == (is_active == "true"))
    return q.order_by(models.Kasa.kod).all()

# -------------------------------------------------------------------
# Detay
# -------------------------------------------------------------------
@router.get("/{kasa_id}", response_model=schemas.KasaOut)
def get_kasa(kasa_id: int, db: Session = Depends(get_db)):
    obj = db.query(models.Kasa).filter(models.Kasa.id == kasa_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Kasa/Banka bulunamadı")
    return obj

# -------------------------------------------------------------------
# Oluştur (+ finans_islemler'e açılış hareketi)
# -------------------------------------------------------------------
@router.post("/", response_model=schemas.KasaOut)
def create_kasa(kasa: schemas.KasaCreate, db: Session = Depends(get_db)):
    kasa_kod = _normalize_kod(kasa.kod)

    if kasa.tur not in ("Kasa", "Banka"):
        raise HTTPException(status_code=422, detail="tur yalnızca 'Kasa' veya 'Banka' olabilir.")

    belge_tipi = _resolve_belge_tipi(kasa)
    alan_id = getattr(kasa, "alan_id", None)

    if not _belge_seri_var(db, modul="Finansman", belge_tipi=belge_tipi, alan_id=alan_id):
        raise HTTPException(status_code=400, detail=f"Belge serisi tanımlı değil: {belge_tipi}")

    belge_seri, belge_no_int, full_no = _get_number(
        db, modul="Finansman", belge_tipi=belge_tipi, alan_id=alan_id
    )

    try:
        # 1) KART
        data = kasa.dict(exclude={"alan_id", "kod", "acilis_aciklama"})
        # normalize doviz
        data["doviz"] = _norm_doviz(data.get("doviz"))
        # kasa ise banka alanlarını temizle
        if kasa.tur == "Kasa":
            data["alt_tur"] = None
            data["banka_adi"] = None
            data["iban"] = None

        obj = models.Kasa(
            **data,
            kod=kasa_kod,
            belge_tipi=belge_tipi,
            belge_seri=belge_seri,
            belge_no=full_no,  # kartta full string'i tut
        )
        db.add(obj)
        db.flush()  # obj.id için

        # 2) Açılış hareketi -> finans_islemler (+ HP/Cari)
        acilis_tutari = _parse_decimal(kasa.acilis_tutari)
        acilis_tarih = kasa.acilis_tarih or date.today()
        aciklama = (kasa.acilis_aciklama or f"{belge_tipi} açılış hareketi").strip()
        yon = _normalize_yon(kasa.acilis_yonu)

        if acilis_tutari > 0:
            # FinansIslem (kasa/banka)
            _insert_finans_islem(
                db,
                kasa_obj=obj,
                belge_tipi=belge_tipi,
                belge_seri=belge_seri,
                belge_no_int=belge_no_int,
                acilis_tutari=acilis_tutari,
                acilis_yonu=yon,
                acilis_tarih=acilis_tarih,
                aciklama=aciklama,
            )

            # Muhasebe / Cari (full_no string)
            if not _full_no_kullaniliyor_mu(db, full_no):
                # Hesap Planı
                hp = _resolve_hesap_plani(db, obj)
                if hp:
                    db.add(models.HesapPlaniIslem(
                        hesap_id=hp.id,
                        tarih=acilis_tarih,
                        aciklama=aciklama,
                        belge_seri=belge_seri,
                        belge_no=full_no,  # string unique
                        borc=float(acilis_tutari if yon == "Borç" else 0),
                        alacak=float(acilis_tutari if yon == "Alacak" else 0),
                        bakiye=float(
                            (acilis_tutari if yon == "Borç" else 0)
                            - (acilis_tutari if yon == "Alacak" else 0)
                        ),
                        hesap_kodu=obj.kod,
                    ))

                # Cari
                cari = db.query(models.Cari).filter_by(hesap_kodu=obj.kod).first()
                if cari:
                    borc = acilis_tutari if yon == "Borç" else Decimal("0")
                    alacak = acilis_tutari if yon == "Alacak" else Decimal("0")
                    bakiye = borc - alacak
                    db.add(models.CariIslem(
                        cari_id=cari.id,
                        tarih=acilis_tarih,
                        aciklama=aciklama,
                        belge_tipi=belge_tipi,
                        belge_seri=belge_seri,
                        belge_no=full_no,  # string unique
                        borc=borc,
                        alacak=alacak,
                        bakiye=bakiye,
                        hesap_kodu=obj.kod,
                    ))

        db.commit()
        db.refresh(obj)
        return obj

    except IntegrityError as ie:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Kayıt oluşturulamadı (integrity): {ie}")
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Beklenmeyen hata: {e}")

# -------------------------------------------------------------------
# Güncelle
# -------------------------------------------------------------------
@router.put("/{kasa_id}", response_model=schemas.KasaOut)
def update_kasa(kasa_id: int, kasa: schemas.KasaUpdate, db: Session = Depends(get_db)):
    obj = db.query(models.Kasa).filter(models.Kasa.id == kasa_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Kasa/Banka bulunamadı")

    data = kasa.dict(exclude_unset=True)
    # kart üzerinde açılış/numara alanlarını güncellemeye izin verme
    for imm in ["belge_tipi", "belge_seri", "belge_no", "acilis_tutari", "acilis_yonu", "acilis_aciklama"]:
        data.pop(imm, None)

    if "kod" in data:
        data["kod"] = _normalize_kod(data["kod"])

    if "doviz" in data:
        data["doviz"] = _norm_doviz(data["doviz"])

    if data.get("tur") == "Kasa":
        data.pop("alt_tur", None)
        data.pop("banka_adi", None)
        data.pop("iban", None)

    for k, v in data.items():
        setattr(obj, k, v)

    try:
        db.commit()
        db.refresh(obj)
        return obj
    except IntegrityError as ie:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Güncelleme başarısız (integrity): {ie}")

# -------------------------------------------------------------------
# Sil
# -------------------------------------------------------------------
@router.delete("/{kasa_id}")
def delete_kasa(kasa_id: int, db: Session = Depends(get_db)):
    obj = db.query(models.Kasa).filter(models.Kasa.id == kasa_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Kasa/Banka bulunamadı")
    db.delete(obj)
    db.commit()
    return {"ok": True}

# -------------------------------------------------------------------
# Ekstre – finans_islemler
# -------------------------------------------------------------------
@router.get("/{kasa_id}/islemler", response_model=list[schemas.FinansIslemOut])
def list_kasa_islemleri(kasa_id: int, db: Session = Depends(get_db)):
    if not db.query(models.Kasa.id).filter(models.Kasa.id == kasa_id).first():
        raise HTTPException(status_code=404, detail="Kasa/Banka bulunamadı")

    return (
        db.query(models.FinansIslem)
        .filter(models.FinansIslem.kasa_id == kasa_id)
        .order_by(models.FinansIslem.tarih, models.FinansIslem.id)
        .all()
    )
