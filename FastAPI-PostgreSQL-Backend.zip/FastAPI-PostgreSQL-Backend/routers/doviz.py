from fastapi import APIRouter, Depends, HTTPException
from xml.etree import ElementTree
from sqlalchemy.orm import Session
from datetime import date
import httpx

import crud, schemas
from database import get_db

router = APIRouter(prefix="/doviz-turleri", tags=["Döviz Türleri"])

# === 1. Sabit Döviz Türleri (UI dropdown için) ===
@router.get("/")
async def get_static_dovizler():
    return [
        {"id": 1, "kod": "TRY", "ad": "Türk Lirası"},
        {"id": 2, "kod": "USD", "ad": "Amerikan Doları"},
        {"id": 3, "kod": "EUR", "ad": "Euro"},
        {"id": 4, "kod": "GBP", "ad": "İngiliz Sterlini"},
        {"id": 5, "kod": "CHF", "ad": "İsviçre Frangı"},
    ]


# === 2. TCMB'den bugünkü döviz kurlarını çekip veritabanına kaydet ===
@router.post("/tcmb-guncelle")
async def guncelle_tcmb_kurlari(db: Session = Depends(get_db)):
    try:
        url = "https://www.tcmb.gov.tr/kurlar/today.xml"
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            xml = ElementTree.fromstring(response.text)

        today = date.today()
        kurlar = []

        for currency in xml.findall("Currency"):
            kod = currency.attrib.get("CurrencyCode")
            alis = currency.findtext("ForexBuying")
            satis = currency.findtext("ForexSelling")
            efektif_alis = currency.findtext("BanknoteBuying")
            efektif_satis = currency.findtext("BanknoteSelling")

            if kod:
                kur = schemas.DovizKurCreate(
                    kod=kod,
                    tarih=today,
                    alis=alis.replace(",", ".") if alis else None,
                    satis=satis.replace(",", ".") if satis else None,
                    efektif_alis=efektif_alis.replace(",", ".") if efektif_alis else None,
                    efektif_satis=efektif_satis.replace(",", ".") if efektif_satis else None,
                    kaynak="TCMB"
                )
                crud.create_kur(db, kur)
                kurlar.append(kur.kod)

        return {
            "kaynak": "TCMB",
            "tarih": str(today),
            "adet": len(kurlar),
            "kurlar": kurlar
        }

    except httpx.RequestError as e:
        raise HTTPException(status_code=502, detail=f"TCMB bağlantı hatası: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Kurlar güncellenemedi: {str(e)}")


# === 3. Bugünkü döviz kurlarını veritabanından getir ===
@router.get("/bugun", response_model=list[schemas.DovizKurOut])
def bugunku_kurlar(db: Session = Depends(get_db)):
    try:
        return crud.get_kurlar_by_tarih(db, tarih=date.today())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Veri alınamadı: {str(e)}")


# === 4. Son güncellenen tarihli döviz kurlarını getir ===
@router.get("/son", response_model=list[schemas.DovizKurOut])
def son_kurlar(db: Session = Depends(get_db)):
    try:
        return crud.get_son_kurlar(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Veri alınamadı: {str(e)}")


# === 5. Belirli bir tarihe ait döviz kurlarını getir (opsiyonel) ===
@router.get("/tarih", response_model=list[schemas.DovizKurOut])
def kurlar_by_tarih(tarih: date, db: Session = Depends(get_db)):
    try:
        return crud.get_kurlar_by_tarih(db, tarih=tarih)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{tarih} tarihli veriler alınamadı: {str(e)}")
