from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os

# .env kullanılabilir ancak şu an sabit değerle tanımlıyoruz
SQLALCHEMY_DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:1q2w3e4r@localhost/nova"  # kendi veritabanı bilgine göre
)

# PostgreSQL için bağlantı motoru
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Oturum (session) yöneticisi
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Model tanımlarının miras alacağı temel sınıf
Base = declarative_base()

# FastAPI içinde kullanılacak bağımlılık (dependency)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
