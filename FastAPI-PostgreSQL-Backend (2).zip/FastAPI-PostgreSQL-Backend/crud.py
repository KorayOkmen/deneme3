from sqlalchemy.orm import Session
from passlib.context import CryptContext
from fastapi import HTTPException
import models, schemas
from datetime import date, datetime
from sqlalchemy import func  # 🔧 EKLENMELİ (get_son_kurlar için gerekli)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ============================================================
# === KULLANICI YÖNETİMİ
# ============================================================

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_user(db: Session, user: schemas.UserCreate):
    hashed_pw = get_password_hash(user.password)
    db_user = models.User(
        personel_code=user.personel_code,
        email=user.email,
        hashed_password=hashed_pw,
        full_name=user.full_name,
        department_id=user.department_id,
        unvan_id=user.unvan_id,
        phone=user.phone,
        title=user.title,
        is_active=user.is_active
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def update_user(db: Session, user_id: int, updated_data: schemas.UserUpdate):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    for field, value in updated_data.dict(exclude_unset=True).items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return user

def get_users(db: Session):
    return db.query(models.User).all()

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

# ============================================================
# === UNVAN YÖNETİMİ
# ============================================================

def get_unvanlar(db: Session, sadece_aktifler: bool = True):
    query = db.query(models.Unvan)
    if sadece_aktifler:
        query = query.filter(models.Unvan.aktif == True)
    return query.order_by(models.Unvan.ad.asc()).all()

def create_unvan(db: Session, unvan: schemas.UnvanCreate):
    if db.query(models.Unvan).filter(models.Unvan.ad == unvan.ad).first():
        raise HTTPException(status_code=409, detail="Bu unvan zaten mevcut.")
    db_unvan = models.Unvan(ad=unvan.ad)
    db.add(db_unvan)
    db.commit()
    db.refresh(db_unvan)
    return db_unvan

def update_unvan(db: Session, unvan_id: int, guncel_veri: schemas.UnvanUpdate):
    db_unvan = db.query(models.Unvan).filter(models.Unvan.id == unvan_id).first()
    if not db_unvan:
        raise HTTPException(status_code=404, detail="Unvan bulunamadı")

    for field, value in guncel_veri.dict(exclude_unset=True).items():
        setattr(db_unvan, field, value)

    db.commit()
    db.refresh(db_unvan)
    return db_unvan

def deactivate_unvan(db: Session, unvan_id: int):
    db_unvan = db.query(models.Unvan).filter(models.Unvan.id == unvan_id).first()
    if not db_unvan:
        raise HTTPException(status_code=404, detail="Unvan bulunamadı")
    
    db_unvan.aktif = False
    db.commit()
    return {"ok": True}

# ============================================================
# === YETKİLER
# ============================================================

def create_permission(db: Session, permission: schemas.PermissionCreate, role_id: int):
    db_perm = models.Permission(
        module=permission.module,
        action=permission.action,
        role_id=role_id
    )
    db.add(db_perm)
    db.commit()
    db.refresh(db_perm)
    return db_perm

def get_permissions_by_role(db: Session, role_id: int):
    return db.query(models.Permission).filter(models.Permission.role_id == role_id).all()

# ============================================================
# === ROL GRUBU YÖNETİMİ
# ============================================================

def create_role_group(db: Session, group: schemas.RoleGroupCreate):
    db_group = models.RoleGroup(
        name=group.name,
        description=group.description
    )
    db_roles = db.query(models.Role).filter(models.Role.id.in_(group.role_ids)).all()
    db_group.roles = db_roles
    db.add(db_group)
    db.commit()
    db.refresh(db_group)
    return db_group

def get_role_groups(db: Session):
    return db.query(models.RoleGroup).all()

def assign_role_group_to_user(db: Session, user_id: int, role_group_id: int):
    user_group = models.UserRoleGroup(
        user_id=user_id,
        role_group_id=role_group_id
    )
    db.add(user_group)
    db.commit()
    db.refresh(user_group)
    return user_group

# ============================================================
# === REZERVASYON SİSTEMİ
# ============================================================

def create_rezervasyon(db: Session, rezervasyon: schemas.RezervasyonCreate, force: bool = False):
    mevcut = db.query(models.Rezervasyon).filter(
        models.Rezervasyon.tarih == rezervasyon.tarih,
        models.Rezervasyon.saat == rezervasyon.saat,
        models.Rezervasyon.ilgili_id == rezervasyon.ilgili
    ).first()

    if mevcut and not force:
        raise HTTPException(
            status_code=409,
            detail="Bu personel bu tarih ve saatte başka bir rezervasyona atanmış."
        )

    db_rez = models.Rezervasyon(
        musteri=rezervasyon.musteri,
        hizmet=rezervasyon.hizmet,
        tarih=rezervasyon.tarih,
        saat=rezervasyon.saat,
        not_=rezervasyon.not_,
        durum=rezervasyon.durum,
        ilgili_id=rezervasyon.ilgili
    )
    db.add(db_rez)
    db.commit()
    db.refresh(db_rez)
    return db_rez

def get_rezervasyonlar(db: Session):
    return db.query(models.Rezervasyon).order_by(
        models.Rezervasyon.tarih.desc(),
        models.Rezervasyon.saat.desc()
    ).all()

def get_rezervasyon_by_id(db: Session, rezervasyon_id: int):
    return db.query(models.Rezervasyon).filter(models.Rezervasyon.id == rezervasyon_id).first()

def delete_rezervasyon(db: Session, rezervasyon_id: int):
    rezervasyon = get_rezervasyon_by_id(db, rezervasyon_id)
    if rezervasyon:
        db.delete(rezervasyon)
        db.commit()
        return True
    return False

def update_rezervasyon_durum(db: Session, rezervasyon_id: int, yeni_durum: str):
    rezervasyon = get_rezervasyon_by_id(db, rezervasyon_id)
    if rezervasyon:
        rezervasyon.durum = yeni_durum
        db.commit()
        db.refresh(rezervasyon)
        return rezervasyon
    return None
# ============================================================
# === DEPARTMAN YÖNETİMİ
# ============================================================

def get_departmanlar(db: Session, sadece_aktifler: bool = True):
    query = db.query(models.Departman)
    if sadece_aktifler:
        query = query.filter(models.Departman.aktif == True)
    return query.order_by(models.Departman.ad.asc()).all()

def create_departman(db: Session, departman: schemas.DepartmanCreate):
    if db.query(models.Departman).filter(models.Departman.ad == departman.ad).first():
        raise HTTPException(status_code=409, detail="Bu departman zaten mevcut.")
    db_departman = models.Departman(ad=departman.ad)
    db.add(db_departman)
    db.commit()
    db.refresh(db_departman)
    return db_departman

def update_departman(db: Session, departman_id: int, guncel_veri: schemas.DepartmanUpdate):
    db_departman = db.query(models.Departman).filter(models.Departman.id == departman_id).first()
    if not db_departman:
        raise HTTPException(status_code=404, detail="Departman bulunamadı")

    for field, value in guncel_veri.dict(exclude_unset=True).items():
        setattr(db_departman, field, value)

    db.commit()
    db.refresh(db_departman)
    return db_departman

def deactivate_departman(db: Session, departman_id: int):
    db_departman = db.query(models.Departman).filter(models.Departman.id == departman_id).first()
    if not db_departman:
        raise HTTPException(status_code=404, detail="Departman bulunamadı")

    db_departman.aktif = False
    db.commit()
    return {"ok": True}
# ============================================================
# === ALAN YÖNETİMİ
# ============================================================

def get_alanlar(db: Session, sadece_aktifler: bool = True):
    query = db.query(models.Alan)
    if sadece_aktifler:
        query = query.filter(models.Alan.aktif == True)
    return query.order_by(models.Alan.ad.asc()).all()

def create_alan(db: Session, alan: schemas.AlanCreate):
    if db.query(models.Alan).filter(models.Alan.ad == alan.ad).first():
        raise HTTPException(status_code=409, detail="Bu alan zaten mevcut.")
    db_alan = models.Alan(ad=alan.ad)
    db.add(db_alan)
    db.commit()
    db.refresh(db_alan)
    return db_alan

def update_alan(db: Session, alan_id: int, guncel_veri: schemas.AlanUpdate):
    db_alan = db.query(models.Alan).filter(models.Alan.id == alan_id).first()
    if not db_alan:
        raise HTTPException(status_code=404, detail="Alan bulunamadı")

    for field, value in guncel_veri.dict(exclude_unset=True).items():
        setattr(db_alan, field, value)

    db.commit()
    db.refresh(db_alan)
    return db_alan

def deactivate_alan(db: Session, alan_id: int):
    db_alan = db.query(models.Alan).filter(models.Alan.id == alan_id).first()
    if not db_alan:
        raise HTTPException(status_code=404, detail="Alan bulunamadı")

    db_alan.aktif = False
    db.commit()
    return {"ok": True}
def update_alan(db: Session, alan_id: int, payload: schemas.AlanUpdate):
    alan = db.query(models.Alan).filter(models.Alan.id == alan_id).first()
    if not alan:
        raise HTTPException(status_code=404, detail="Alan bulunamadı")

    if payload.ad is not None:
        alan.ad = payload.ad
    if payload.aktif is not None:
        alan.aktif = payload.aktif

    db.commit()
    db.refresh(alan)
    return alan

# ============================================================
# === Hizmet Türü
# ============================================================
def get_hizmet_turleri(db: Session):
    return db.query(models.HizmetTuru).filter(models.HizmetTuru.aktif == True).all()

def create_hizmet_turu(db: Session, payload: schemas.HizmetTuruCreate):
    yeni = models.HizmetTuru(ad=payload.ad)
    db.add(yeni)
    db.commit()
    db.refresh(yeni)
    return yeni

def update_hizmet_turu(db: Session, hizmet_id: int, payload: schemas.HizmetTuruCreate):
    hizmet = db.query(models.HizmetTuru).filter(models.HizmetTuru.id == hizmet_id).first()
    if not hizmet:
        raise HTTPException(status_code=404, detail="Hizmet türü bulunamadı")
    hizmet.ad = payload.ad
    db.commit()
    db.refresh(hizmet)
    return hizmet

def deactivate_hizmet_turu(db: Session, hizmet_id: int):
    hizmet = db.query(models.HizmetTuru).filter(models.HizmetTuru.id == hizmet_id).first()
    if not hizmet:
        raise HTTPException(status_code=404, detail="Hizmet türü bulunamadı")
    hizmet.aktif = False
    db.commit()
    return {"detail": "Pasif hale getirildi"}

# === Hizmet Türü Aktif Et ===
def aktif_et_hizmet_turu(db: Session, hizmet_turu_id: int):
    hizmet = db.query(models.HizmetTuru).filter(models.HizmetTuru.id == hizmet_turu_id).first()
    if not hizmet:
        raise HTTPException(status_code=404, detail="Hizmet türü bulunamadı")

    hizmet.aktif = True
    db.commit()
    db.refresh(hizmet)
    return hizmet
# ============================================================
# === DÖVİZ KURLARI
# ============================================================

def create_kur(db: Session, kur: schemas.DovizKurCreate):
    mevcut = db.query(models.DovizKur).filter(
        models.DovizKur.kod == kur.kod,
        models.DovizKur.tarih == kur.tarih
    ).first()

    if mevcut:
        # Güncelleme: var olan kuru güncelle
        mevcut.alis = kur.alis
        mevcut.satis = kur.satis
        mevcut.efektif_alis = kur.efektif_alis          # 🆕 EKLENDİ
        mevcut.efektif_satis = kur.efektif_satis        # 🆕 EKLENDİ
        mevcut.kaynak = kur.kaynak
        db.commit()
        db.refresh(mevcut)
        return mevcut

    # Yeni kayıt
    yeni = models.DovizKur(
        kod=kur.kod,
        tarih=kur.tarih,
        alis=kur.alis,
        satis=kur.satis,
        efektif_alis=kur.efektif_alis,          # 🆕 EKLENDİ
        efektif_satis=kur.efektif_satis,        # 🆕 EKLENDİ
        kaynak=kur.kaynak
    )
    db.add(yeni)
    db.commit()
    db.refresh(yeni)
    return yeni
def get_kurlar_by_tarih(db: Session, tarih: date):
    return (
        db.query(models.DovizKur)
        .filter(models.DovizKur.tarih == tarih)
        .order_by(models.DovizKur.kod)
        .all()
    )
def get_son_kurlar(db: Session):
    son_tarih = db.query(func.max(models.DovizKur.tarih)).scalar()
    if not son_tarih:
        return []
    return (
        db.query(models.DovizKur)
        .filter(models.DovizKur.tarih == son_tarih)
        .order_by(models.DovizKur.kod)
        .all()
    )
def get_kurlar_by_kod(db: Session, kodlar: list[str], tarih: date = date.today()):
    return (
        db.query(models.DovizKur)
        .filter(models.DovizKur.tarih == tarih)
        .filter(models.DovizKur.kod.in_(kodlar))
        .order_by(models.DovizKur.kod)
        .all()
    )
def get_kur_gunluk_ortalama(db: Session, kod: str, baslangic: date, bitis: date):
    return db.query(
        func.avg(models.DovizKur.satis).label("ortalama_satis"),
        func.avg(models.DovizKur.alis).label("ortalama_alis")
    ).filter(
        models.DovizKur.kod == kod,
        models.DovizKur.tarih >= baslangic,
        models.DovizKur.tarih <= bitis
    ).first()
