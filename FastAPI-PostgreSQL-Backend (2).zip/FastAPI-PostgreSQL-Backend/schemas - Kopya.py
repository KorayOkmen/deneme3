from pydantic import BaseModel, Field ,constr, field_validator
from typing import Optional, List
from datetime import date, time, datetime
from enum import Enum

# === Departman ===
class DepartmanBase(BaseModel):
    ad: str

class DepartmanCreate(DepartmanBase):
    pass

class DepartmanUpdate(BaseModel):
    ad: str
    aktif: bool = True  # Güncelleme sırasında aktiflik de değişebilir

class DepartmanOut(DepartmanBase):
    id: int
    aktif: bool

    class Config:
        from_attributes = True  # Pydantic v2 için
# === Unvan ===
from pydantic import BaseModel

class UnvanBase(BaseModel):
    ad: str

class UnvanCreate(UnvanBase):
    pass

class UnvanUpdate(BaseModel):
    ad: str
    aktif: bool = True  # Unvan güncellenirken aktiflik de değişebilir

class UnvanOut(UnvanBase):
    id: int
    aktif: bool

    class Config:
        from_attributes = True  # Pydantic v2 için



# === Users ===
class UserCreate(BaseModel):
    personel_code: str
    email: str
    password: str
    full_name: Optional[str] = None
    department_id: Optional[int] = None
    unvan_id: Optional[int] = None
    phone: Optional[str] = None
    title: Optional[str] = None
    is_active: Optional[bool] = True


class UserLogin(BaseModel):
    email: str
    password: str

class UserUpdate(BaseModel):
    personel_code: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = None
    full_name: Optional[str] = None
    department_id: Optional[int] = None
    unvan_id: Optional[int] = None
    phone: Optional[str] = None
    title: Optional[str] = None
    is_active: Optional[bool] = None

class UserOut(BaseModel):
    id: int
    personel_code: Optional[str]
    email: str
    full_name: Optional[str] = None
    phone: Optional[str] = None
    title: Optional[str] = None
    is_active: Optional[bool] = True
    department: Optional[DepartmanOut] = None
    unvan: Optional[UnvanOut] = None

    class Config:
        from_attributes = True

# === Issues ===
class IssueCreate(BaseModel):
    konu: str
    oncelik: Optional[str] = None
    etiketler: List[str] = []
    aciklama: str
    modul: str
    durum: str = "Kayıt Açık"
    ilgili: Optional[str] = None

class IssueOut(IssueCreate):
    has_file: Optional[bool] = False
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class IssueUpdateStatus(BaseModel):
    durum: str

# === Comments ===
class CommentCreate(BaseModel):
    issue_id: int
    text: str
    durum: str = "Kayıt Açık"

class CommentOut(BaseModel):
    id: int
    issue_id: int
    text: str
    durum: str
    has_file: Optional[bool] = False
    created_at: datetime

    class Config:
        from_attributes = True

# === Legacy Role & Permission ===
class PermissionBase(BaseModel):
    module: str
    action: str

class PermissionCreate(PermissionBase):
    pass

class PermissionOut(PermissionBase):
    id: int

    class Config:
        from_attributes = True

class RoleBase(BaseModel):
    name: str

class RoleCreate(RoleBase):
    pass

class RoleOutLegacy(RoleBase):
    id: int
    permissions: List[PermissionOut] = []

    class Config:
        from_attributes = True

class RoleGroupBase(BaseModel):
    name: str
    description: Optional[str] = None

class RoleGroupCreate(RoleGroupBase):
    role_ids: List[int] = []

class RoleGroupOut(RoleGroupBase):
    id: int
    roles: List[RoleOutLegacy] = []

    class Config:
        from_attributes = True

class UserRoleGroupBase(BaseModel):
    user_id: int
    group_id: int

class UserRoleGroup(UserRoleGroupBase):
    id: int

    class Config:
        from_attributes = True

class UserRoleGroupOut(BaseModel):
    id: int
    role_group: RoleGroupOut

    class Config:
        from_attributes = True

# === Alan Tanımı ===
class AlanBase(BaseModel):
    ad: str

class AlanCreate(AlanBase):
    pass

class AlanUpdate(BaseModel):
    ad: str
    aktif: bool = True

class AlanOut(AlanBase):
    id: int
    aktif: bool

    class Config:
        from_attributes = True
class AlanUpdate(BaseModel):
    ad: Optional[str] = None
    aktif: Optional[bool] = None


# === Proje ===
class ProjectBase(BaseModel):
    proje_adi: str
    musteri: Optional[str] = None
    baslangic: date
    aciklama: Optional[str] = None

class ProjectCreate(ProjectBase):
    pass

class ProjectShortOut(BaseModel):
    id: int
    proje_adi: str

    class Config:
        from_attributes = True

class ProjectOut(ProjectBase):
    id: int
    tamamlandi: bool = False
    plans: List["PlanOut"] = []

    class Config:
        from_attributes = True

# === Planlama ===
class PlanBase(BaseModel):
    ad: str
    sorumlu: str
    calisma_sekli: str
    baslangic: datetime
    bitis: datetime
    aciklama: Optional[str] = None
    proje_id: int
    alan_id: Optional[int] = None

class PlanCreate(PlanBase):
    pass

class PlanOut(PlanBase):
    id: int
    olusturma: datetime
    project: Optional[ProjectShortOut]
    alan: Optional[AlanOut]

    class Config:
        from_attributes = True

# === Hizmet Türü ===
class HizmetTuruBase(BaseModel):
    ad: str

class HizmetTuruCreate(HizmetTuruBase):
    pass

class HizmetTuruOut(HizmetTuruBase):
    id: int
    aktif: bool = True

    class Config:
        from_attributes = True


# === Rezervasyon ===
class RezervasyonCreate(BaseModel):
    musteri: str
    hizmet: str
    tarih: date
    saat: time
    not_: Optional[str] = None
    durum: str = "Açık"
    ilgili: int
    force: bool = False

class RezervasyonOut(BaseModel):
    id: int
    musteri: str
    hizmet: str
    tarih: date
    saat: time
    not_: Optional[str] = None
    durum: str
    ilgili: UserOut

    class Config:
        from_attributes = True

# === Durum Güncelleme ===
class DurumGuncelle(BaseModel):
    yeni_durum: str
class _CariIntsMixin(BaseModel):
    tahsilat_gunu: Optional[int] = None
    tahsilat_vadesi: Optional[int] = None

    @field_validator("tahsilat_gunu", "tahsilat_vadesi", mode="before")
    @classmethod
    def _empty_str_to_none_and_cast_int(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            if v.strip() == "" or v.strip().lower() == "null":
                return None
            # "12" gibi string gelirse int'e çevir
            return int(v)
        # sayısal gelirse direkt bırak
        return v

class CariBase(_CariIntsMixin):
    hesap_tipi: str
    hesap_turu: Optional[str] = None
    hesap_kodu: Optional[str] = None
    unvan: str
    telefon: Optional[str] = None
    email: Optional[str] = None
    vergi_no: Optional[str] = None
    vergi_dairesi: Optional[str] = None
    adres: Optional[str] = None
    posta_kodu: Optional[str] = None
    ilce: Optional[str] = None
    il: Optional[str] = None
    ulke: Optional[str] = None
    doviz_turu: Optional[str] = None
    aciklama: Optional[str] = None
    is_active: bool = True
    satis_kanali: Optional[str] = None
    hesap_grubu: Optional[str] = None
    sektor: Optional[str] = None

    belge_tipi: Optional[str] = None
    belge_seri: Optional[str] = None
    belge_no: Optional[int] = None
    muhasebe_hesabi: Optional[str] = None

class CariCreate(CariBase):
    pass

class CariUpdate(_CariIntsMixin):
    hesap_tipi: Optional[str] = None
    hesap_turu: Optional[str] = None
    hesap_kodu: Optional[str] = None
    unvan: Optional[str] = None
    telefon: Optional[str] = None
    email: Optional[str] = None
    vergi_no: Optional[str] = None
    vergi_dairesi: Optional[str] = None
    adres: Optional[str] = None
    posta_kodu: Optional[str] = None
    ilce: Optional[str] = None
    il: Optional[str] = None
    ulke: Optional[str] = None
    doviz_turu: Optional[str] = None
    aciklama: Optional[str] = None
    is_active: Optional[bool] = None
    satis_kanali: Optional[str] = None
    hesap_grubu: Optional[str] = None
    sektor: Optional[str] = None

    belge_tipi: Optional[str] = None
    belge_seri: Optional[str] = None
    belge_no: Optional[int] = None

class CariOut(CariBase):
    id: int
    class Config:
        from_attributes = True

# === Döviz Kurları ===
class DovizKurBase(BaseModel):
    kod: str
    tarih: date
    alis: Optional[str] = None
    satis: Optional[str] = None
    efektif_alis: Optional[str] = None
    efektif_satis: Optional[str] = None
    kaynak: Optional[str] = "TCMB"

class DovizKurCreate(DovizKurBase):
    pass

class DovizKurOut(DovizKurBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
# === Ekstre ===
class EkstreOut(BaseModel):
    tarih: date
    aciklama: str
    borc: float
    alacak: float
    bakiye: float

    class Config:
        from_attributes = True

# === Kasa ===
class KasaBase(BaseModel):
    kod: str                                # ✅ Bu satır varsa sorun yok
    ad: str
    tur: str
    alt_tur: Optional[str] = None
    doviz: str
    banka_adi: Optional[str] = None
    iban: Optional[str] = None
    aciklama: Optional[str] = None
    is_active: bool = True

    # 🔽 Yeni alanlar (Create'te gerekmez ama Out'ta görünmeli)
    belge_tipi: Optional[str] = None
    belge_seri: Optional[str] = None

class KasaCreate(KasaBase):
    pass

class KasaUpdate(KasaBase):
    pass

class KasaOut(KasaBase):
    id: int

class Config:
    from_attributes = True

# === Hesap Planı Şemaları ===
from pydantic import BaseModel

# === Hesap Planı Şemaları ===
# === ANA HESAP PLANI ===
class HesapPlaniBase(BaseModel):
    kod: str
    ad: str
    hesap_tipi: Optional[str] = None
    bilanco_tipi: Optional[str] = None
    doviz_turu: Optional[str] = "TRY"
    kur_turu: Optional[str] = None
    ana_hesap: Optional[bool] = False
    ust_hesap_kodu: Optional[str] = None
    grup: Optional[str] = None
    fislerde_kullanilabilir: Optional[bool] = True
    aktif: Optional[bool] = True
    aciklama: Optional[str] = None

class HesapPlaniCreate(HesapPlaniBase):
    pass

class HesapPlaniUpdate(HesapPlaniBase):
    pass

class HesapPlaniOut(HesapPlaniBase):
    id: int

    class Config:
       from_attributes = True
# === HESAP PLANI İŞLEM ŞEMALARI ===
class HesapPlaniIslemBase(BaseModel):
    hesap_id: int
    tarih: date
    aciklama: Optional[str] = None
    belge_tipi: Optional[str] = "Hesap Planı Açılışı"
    belge_seri: Optional[str] = "GA"
    borc: float = 0
    alacak: float = 0
    bakiye: float = 0

class HesapPlaniIslemCreate(HesapPlaniIslemBase):
    pass

class HesapPlaniIslemOut(HesapPlaniIslemBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# === Ödeme Vadesi Şemaları ===
class OdemeVadesiBase(BaseModel):
    kod: str  # ✅ YENİ EKLENDİ
    ad: str
    gun_sayisi: int
    aktif: bool = True

class OdemeVadesiCreate(OdemeVadesiBase):
    pass

class OdemeVadesiUpdate(BaseModel):
    kod: Optional[str] = None  # ✅ Güncellemede opsiyonel
    ad: Optional[str] = None
    gun_sayisi: Optional[int] = None
    aktif: Optional[bool] = None

class OdemeVadesiOut(OdemeVadesiBase):
    id: int

    class Config:
        from_attributes = True

# === Virman ===

class HesapTipi(str, Enum):
    kasa = "Kasa"
    banka = "Banka"
    musteri = "Müşteri"
    tedarikci = "Tedarikçi"
    genel = "Genel"

class IslemTipi(str, Enum):
    borc = "Borç"
    alacak = "Alacak"

# === DETAY / MADDE ŞEMALARI ===

class VirmanIslemDetayBase(BaseModel):
    hesap_tipi: HesapTipi                      # Enum kullanımı
    cari_kod: Optional[str] = None             # Genel hesap için boş olabilir
    tutar: float = Field(..., gt=0)            # Pozitif tutar
    islem_tipi: IslemTipi                      # Enum
    vade_tarihi: Optional[date] = None
    aciklama: Optional[str] = None

class VirmanIslemDetayCreate(VirmanIslemDetayBase):
    pass

class VirmanIslemDetayOut(VirmanIslemDetayBase):
    id: int
    virman_islem_id: int

    class Config:
        from_attributes = True

# === BAŞLIK / VİRMAN ŞEMALARI ===

class VirmanIslemBase(BaseModel):
    belge_tipi: str = "Virman"
    hesap_tipi: HesapTipi
    cari_kod: Optional[str] = None
    aciklama: Optional[str] = None
    tarih: date = Field(default_factory=date.today)
    doviz_turu: Optional[str] = "TRY"
    kur: Optional[float] = 1.0
    toplam_tutar: Optional[float] = 0.0
    kaydeden: Optional[str] = None

class VirmanIslemCreate(VirmanIslemBase):
    detaylar: Optional[List[VirmanIslemDetayCreate]] = Field(default_factory=list)

class VirmanIslemOut(VirmanIslemBase):
    id: int
    detaylar: List[VirmanIslemDetayOut] = []

    class Config:
        from_attributes = True

# === Belge Seri ===

class BelgeSeriBase(BaseModel):
    modul: str
    belge_tipi: str
    alan_id: Optional[int] = None
    seri_kodu: constr(min_length=2, max_length=2)
    pad_length: int = 6
    prefix: Optional[str] = None
    suffix: Optional[str] = None
    yil_bazli: bool = True
    ay_bazli: bool = False
    aktif: bool = True
    aciklama: Optional[str] = None

class BelgeSeriCreate(BelgeSeriBase): pass

class BelgeSeriOut(BelgeSeriBase):
    id: int
    son_yil: Optional[int] = None
    son_ay: Optional[int] = None
    sayac: int
    class Config: from_attributes = True