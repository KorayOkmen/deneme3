import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session

# Veritabanı ve modeller
import models
from database import Base, engine, SessionLocal
from routers import (
    auth,
    login,
    users,
    issues,
    comments,
    export,
    stats,
    rezervasyon,
    projects,
    plans,
    alanlar,
    hizmet_turu,
    unvanlar,
    departments,
    cari,
    doviz,
    ekstre,
    kasa,
    hesap_plani, 
    odeme_vadeleri,
    belge_serileri,
    finansman_islemleri
)
from routers.doviz import guncelle_tcmb_kurlari  # Günlük görev için import

# Veritabanı tablolarını oluştur
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Koray Takip API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Geliştirme için geniş açık bırakabilirsiniz:
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],      # GET, POST, PUT, DELETE, OPTIONS ...
    allow_headers=["*"],      # Content-Type, Authorization, ...
)

# === Router'ları uygulamaya dahil et ===
app.include_router(auth.router)
app.include_router(login.router)
app.include_router(users.router)
app.include_router(issues.router)
app.include_router(comments.router)
app.include_router(export.router)
app.include_router(stats.router)
app.include_router(rezervasyon.router, prefix="/rezervasyonlar", tags=["Rezervasyonlar"])
app.include_router(projects.router, prefix="/projects", tags=["Projects"])
app.include_router(plans.router, prefix="/plans", tags=["Plans"])
app.include_router(alanlar.router)
app.include_router(hizmet_turu.router)
app.include_router(unvanlar.router)
app.include_router(departments.router)
app.include_router(cari.router)
app.include_router(doviz.router)
app.include_router(ekstre.router)
app.include_router(kasa.router)
app.include_router(hesap_plani.router)
app.include_router(odeme_vadeleri.router)
app.include_router(belge_serileri.router)
app.include_router(finansman_islemleri.router)
# === Statik dosya servisi ===
app.mount("/files", StaticFiles(directory="uploaded_files"), name="files")

@app.get("/files/{filename}", tags=["Dosyalar"])
def get_uploaded_file(filename: str):
    file_path = os.path.join("uploaded_files", filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Dosya bulunamadı")
    return FileResponse(path=file_path, filename=filename)


# === OTOMATİK TCMB KURU GÜNCELLEYEN GÖREV ===
def otomatik_kur_guncelle():
    from datetime import date
    import datetime
    import models

    db: Session = SessionLocal()
    try:
        print("🔄 Otomatik TCMB kur güncelleme çalışıyor...")

        # 1. Hafta sonu kontrolü
        if datetime.date.today().weekday() >= 5:
            print("🛑 Hafta sonu. Kur güncellenmedi.")
            return

        # 2. Aynı günün kuru daha önce kaydedildiyse tekrar yazma
        mevcut_kur = db.query(models.DovizKur).filter(models.DovizKur.tarih == date.today()).first()
        if mevcut_kur:
            print("✅ Bugünün kuru zaten kayıtlı. Güncelleme atlandı.")
            return

        # 3. Async TCMB güncelleme çağrısı
        import asyncio
        asyncio.run(guncelle_tcmb_kurlari(db))
        print("✅ Kur güncelleme başarılı.")
    except Exception as e:
        print(f"⚠️ Güncelleme hatası: {e}")
    finally:
        db.close()

# === Scheduler başlat ===
scheduler = BackgroundScheduler()
scheduler.add_job(otomatik_kur_guncelle, trigger="cron", hour=7, minute=0)  # her sabah 07:00'da çalışacak
scheduler.start()
