# routers/hesap_plani.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from datetime import date
import pandas as pd
import io

from database import get_db
import models, schemas
from services.numarator import get_next_number  # varsa böyle, yoksa: from numarator import get_next_number

router = APIRouter(prefix="/hesap-plani", tags=["Hesap Planı"])

# === 1) Listeleme
@router.get("/", response_model=list[schemas.HesapPlaniOut])
def list_hesap_plani(db: Session = Depends(get_db)):
    return db.query(models.HesapPlani).all()

# === 2) Yeni Hesap Planı Kaydı (ve açılış hareketi)
@router.post("/", response_model=schemas.HesapPlaniOut)
def create_hesap_plani(item: schemas.HesapPlaniCreate, db: Session = Depends(get_db)):
    # Tekil kontrol
    exists = db.query(models.HesapPlani).filter(models.HesapPlani.kod == item.kod).first()
    if exists:
        raise HTTPException(status_code=400, detail="Bu hesap kodu zaten mevcut!")

    try:
        # Belge no/seri (2 hane) numaratörden
        alan_id = getattr(item, "alan_id", None)
        num = get_next_number(db, modul="Finansman", belge_tipi="Hesap Planı Açılışı", alan_id=alan_id)

        # Başlık: SADECE belge_seri / belge_no ekle (belge_tipi kolonu modelde yok)
        yeni = models.HesapPlani(
            **item.dict(),
            belge_seri=num["belge_seri"],
            belge_no=num["belge_no"],
        )
        db.add(yeni)
        db.flush()  # id lazım

        # Otomatik açılış hareketi (aynı belge_no/seri) — modelde belge_tipi alanı yok, göndermiyoruz
        islem = models.HesapPlaniIslem(
            hesap_id=yeni.id,
            hesap_kodu=yeni.kod,
            tarih=date.today(),
            belge_seri=num["belge_seri"],
            belge_no=num["belge_no"],
            aciklama=f"{yeni.kod} hesabı için otomatik açılış işlemi",
            borc=0,
            alacak=0,
            bakiye=0,
        )
        db.add(islem)

        db.commit()
        db.refresh(yeni)
        return yeni

    except IntegrityError as ie:
        db.rollback()
        raise HTTPException(status_code=400, detail="Tekil alan ihlali (ör. kod veya belge_no).") from ie
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Kayıt oluşturulamadı: {e}") from e

# === 3) Aktif Olanları Listele
@router.get("/aktif", response_model=list[schemas.HesapPlaniOut])
def get_aktif_hesaplar(db: Session = Depends(get_db)):
    return db.query(models.HesapPlani).filter(models.HesapPlani.aktif == True).all()

# === 4) Kod ile getir
@router.get("/{kod}", response_model=schemas.HesapPlaniOut)
def get_hesap_plani_by_kod(kod: str, db: Session = Depends(get_db)):
    obj = db.query(models.HesapPlani).filter(models.HesapPlani.kod == kod).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Hesap kodu bulunamadı")
    return obj

# === 5) Güncelleme (PATCH)
@router.patch("/{id}", response_model=schemas.HesapPlaniOut)
def update_hesap_plani(id: int, item: schemas.HesapPlaniUpdate, db: Session = Depends(get_db)):
    obj = db.query(models.HesapPlani).filter(models.HesapPlani.id == id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Hesap planı bulunamadı")

    data = item.dict(exclude_unset=True)

    # Belge alanları kullanıcı tarafından değiştirilemez (modelde belge_tipi yok; belge_seri/no sabit)
    for imm in ["belge_seri", "belge_no"]:
        if imm in data:
            data.pop(imm, None)

    # kod değişiyorsa tekil kontrolü
    if "kod" in data and data["kod"] != obj.kod:
        exists = db.query(models.HesapPlani).filter(models.HesapPlani.kod == data["kod"]).first()
        if exists:
            raise HTTPException(status_code=400, detail="Bu hesap kodu zaten mevcut!")

    for k, v in data.items():
        setattr(obj, k, v)

    db.commit()
    db.refresh(obj)
    return obj

# === 6) Güncelleme (PUT)
@router.put("/{id}", response_model=schemas.HesapPlaniOut)
def update_hesap_plani_put(id: int, item: schemas.HesapPlaniUpdate, db: Session = Depends(get_db)):
    obj = db.query(models.HesapPlani).filter(models.HesapPlani.id == id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Hesap planı bulunamadı")

    data = item.dict()

    # Belge alanları immutable
    for imm in ["belge_seri", "belge_no"]:
        data.pop(imm, None)

    # kod tekil kontrol
    if "kod" in data and data["kod"] != obj.kod:
        exists = db.query(models.HesapPlani).filter(models.HesapPlani.kod == data["kod"]).first()
        if exists:
            raise HTTPException(status_code=400, detail="Bu hesap kodu zaten mevcut!")

    for k, v in data.items():
        setattr(obj, k, v)

    db.commit()
    db.refresh(obj)
    return obj

# === 7) Silme
@router.delete("/{id}")
def delete_hesap_plani(id: int, db: Session = Depends(get_db)):
    obj = db.query(models.HesapPlani).filter(models.HesapPlani.id == id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Hesap planı bulunamadı")

    db.delete(obj)
    db.commit()
    return {"ok": True}

# === 8) Excel'den Toplu Yükleme (+ açılış hareketi, numaratörlü)
@router.post("/excel-yukle")
async def import_excel(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    try:
        df = pd.read_excel(io.BytesIO(contents))
    except Exception:
        raise HTTPException(status_code=400, detail="Dosya okunamadı")

    eklenenler = 0
    for _, row in df.iterrows():
        kod = str(row.get("kod") or "").strip()
        ad = str(row.get("ad") or "").strip()
        if not kod or not ad:
            continue
        if db.query(models.HesapPlani).filter_by(kod=kod).first():
            continue

        try:
            # Belge numarası (her hesap için yeni belge)
            num = get_next_number(db, modul="Finansman", belge_tipi="Hesap Planı Açılışı", alan_id=None)

            hesap = models.HesapPlani(
                kod=kod,
                ad=ad,
                hesap_tipi=row.get("hesap_tipi"),
                bilanco_tipi=row.get("bilanco_tipi"),
                doviz_turu=row.get("doviz_turu", "TRY"),
                kur_turu=row.get("kur_turu"),
                ana_hesap=bool(row.get("ana_hesap")),
                ust_hesap_kodu=row.get("ust_hesap_kodu"),
                grup=row.get("grup"),
                fislerde_kullanilabilir=bool(row.get("fislerde_kullanilabilir", True)),
                aktif=bool(row.get("aktif", True)),
                aciklama=row.get("aciklama"),
                belge_seri=num["belge_seri"],
                belge_no=num["belge_no"],
            )
            db.add(hesap)
            db.flush()

            islem = models.HesapPlaniIslem(
                hesap_id=hesap.id,
                hesap_kodu=hesap.kod,
                tarih=date.today(),
                belge_seri=num["belge_seri"],
                belge_no=num["belge_no"],
                aciklama=f"{hesap.kod} hesabı için otomatik açılış işlemi",
                borc=0,
                alacak=0,
                bakiye=0,
            )
            db.add(islem)

            db.commit()
            eklenenler += 1

        except IntegrityError:
            db.rollback()
            # aynı kod veya belge_no çakışırsa atla
            continue
        except Exception:
            db.rollback()
            continue

    return {"eklenen_kayit": eklenenler}
