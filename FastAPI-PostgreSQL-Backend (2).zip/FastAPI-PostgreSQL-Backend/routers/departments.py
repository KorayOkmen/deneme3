from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Departman
from schemas import DepartmanCreate, DepartmanOut, DepartmanUpdate

router = APIRouter(
    prefix="/departments",
    tags=["departments"]
)

# Tüm departmanları getir
@router.get("/", response_model=List[DepartmanOut])
def get_departmanlar(db: Session = Depends(get_db)):
    return db.query(Departman).order_by(Departman.ad).all()

# Yeni departman oluştur
@router.post("/", response_model=DepartmanOut, status_code=status.HTTP_201_CREATED)
def create_departman(dep: DepartmanCreate, db: Session = Depends(get_db)):
    mevcut = db.query(Departman).filter(Departman.ad == dep.ad).first()
    if mevcut:
        raise HTTPException(status_code=400, detail="Bu departman zaten mevcut.")
    
    yeni_dep = Departman(ad=dep.ad)
    db.add(yeni_dep)
    db.commit()
    db.refresh(yeni_dep)
    return yeni_dep

# Departman güncelle
@router.put("/{departman_id}", response_model=DepartmanOut)
def update_departman(departman_id: int, guncel_veri: DepartmanUpdate, db: Session = Depends(get_db)):
    db_dep = db.query(Departman).filter(Departman.id == departman_id).first()
    if not db_dep:
        raise HTTPException(status_code=404, detail="Departman bulunamadı")

    for field, value in guncel_veri.dict(exclude_unset=True).items():
        setattr(db_dep, field, value)

    db.commit()
    db.refresh(db_dep)
    return db_dep

# Departmanı pasifleştir (soft delete)
@router.delete("/{departman_id}", status_code=status.HTTP_204_NO_CONTENT)
def deactivate_departman(departman_id: int, db: Session = Depends(get_db)):
    db_dep = db.query(Departman).filter(Departman.id == departman_id).first()
    if not db_dep:
        raise HTTPException(status_code=404, detail="Departman bulunamadı")
    
    db_dep.aktif = False
    db.commit()
    return
