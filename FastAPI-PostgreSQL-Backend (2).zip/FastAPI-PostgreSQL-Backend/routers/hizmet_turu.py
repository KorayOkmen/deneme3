from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import crud, schemas
from database import get_db

router = APIRouter(
    prefix="/hizmet-turleri",
    tags=["Hizmet Türleri"]
)

@router.get("/", response_model=List[schemas.HizmetTuruOut])
def get_all(db: Session = Depends(get_db)):
    return crud.get_hizmet_turleri(db)

@router.post("/", response_model=schemas.HizmetTuruOut)
def create(payload: schemas.HizmetTuruCreate, db: Session = Depends(get_db)):
    return crud.create_hizmet_turu(db, payload)

@router.put("/{hizmet_id}", response_model=schemas.HizmetTuruOut)
def update(hizmet_id: int, payload: schemas.HizmetTuruCreate, db: Session = Depends(get_db)):
    return crud.update_hizmet_turu(db, hizmet_id, payload)

@router.delete("/{hizmet_id}")
def delete(hizmet_id: int, db: Session = Depends(get_db)):
    return crud.deactivate_hizmet_turu(db, hizmet_id)
@router.put("/aktif-et/{hizmet_turu_id}", response_model=schemas.HizmetTuruOut)
def aktif_et_hizmet_turu(hizmet_turu_id: int, db: Session = Depends(get_db)):
    """
    Pasif durumdaki hizmet türünü tekrar aktif eder
    """
    return crud.aktif_et_hizmet_turu(db, hizmet_turu_id)
