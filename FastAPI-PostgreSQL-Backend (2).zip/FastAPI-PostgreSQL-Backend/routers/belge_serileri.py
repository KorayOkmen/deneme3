from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models, schemas

router = APIRouter(prefix="/belge-serileri", tags=["Belge Serileri"])

@router.get("/", response_model=list[schemas.BelgeSeriOut])
def list_seriler(db: Session = Depends(get_db)):
    return db.query(models.BelgeSeri).all()

@router.post("/", response_model=schemas.BelgeSeriOut)
def create_seri(item: schemas.BelgeSeriCreate, db: Session = Depends(get_db)):
    exists = (db.query(models.BelgeSeri)
                .filter(models.BelgeSeri.modul==item.modul,
                        models.BelgeSeri.belge_tipi==item.belge_tipi,
                        models.BelgeSeri.alan_id==item.alan_id)
                .first())
    if exists:
        raise HTTPException(400, "Bu kapsamda seri zaten tanımlı.")
    obj = models.BelgeSeri(**item.dict())
    db.add(obj); db.commit(); db.refresh(obj)
    return obj
