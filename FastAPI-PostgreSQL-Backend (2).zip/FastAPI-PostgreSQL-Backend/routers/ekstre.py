from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models, schemas

router = APIRouter(prefix="/ekstre", tags=["Ekstre"])

@router.get("/", response_model=list[schemas.EkstreOut])
def get_ekstre(kaynak_tipi: str, kaynak_id: int, db: Session = Depends(get_db)):
    veriler = db.query(models.Ekstre).filter(
        models.Ekstre.kaynak_tipi == kaynak_tipi,
        models.Ekstre.kaynak_id == kaynak_id
    ).order_by(models.Ekstre.tarih).all()

    return veriler  # Boş liste olabilir, 404 döndürmüyoruz
