from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import crud, schemas
from database import get_db

router = APIRouter(
    prefix="/alanlar",
    tags=["Alanlar"]
)

@router.get("/", response_model=List[schemas.AlanOut])
def get_alanlar(db: Session = Depends(get_db)):
    """
    Tüm aktif alanları listeler
    """
    return crud.get_alanlar(db)

@router.post("/", response_model=schemas.AlanOut)
def create_alan(payload: schemas.AlanCreate, db: Session = Depends(get_db)):
    """
    Yeni bir alan oluşturur
    """
    return crud.create_alan(db, payload)

@router.put("/{alan_id}", response_model=schemas.AlanOut)
def update_alan(alan_id: int, payload: schemas.AlanUpdate, db: Session = Depends(get_db)):
    """
    Var olan bir alanı günceller
    """
    return crud.update_alan(db, alan_id, payload)

@router.delete("/{alan_id}")
def deactivate_alan(alan_id: int, db: Session = Depends(get_db)):
    """
    Alanı pasif duruma getirir (soft delete)
    """
    return crud.deactivate_alan(db, alan_id)
