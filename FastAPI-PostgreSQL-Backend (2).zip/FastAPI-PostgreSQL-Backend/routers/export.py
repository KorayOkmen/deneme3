
from fastapi import APIRouter, Request
from fastapi.responses import FileResponse
import pandas as pd
import tempfile
import os

router = APIRouter()

@router.post("/export")
async def export_to_excel(request: Request):
    body = await request.json()
    data = body.get("data", [])

    if not data:
        return {"error": "Veri bulunamadı"}

    df = pd.DataFrame(data)
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        df.to_excel(tmp.name, index=False)
        file_path = tmp.name

    return FileResponse(
        path=file_path,
        filename="rapor.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


from fpdf import FPDF




from fpdf import FPDF

@router.post("/export-pdf")
async def export_to_pdf(request: Request):
    body = await request.json()
    data = body.get("data", [])

    if not data:
        return {"error": "Veri bulunamadı"}

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.add_page()
    pdf.set_font("Helvetica", size=10)

    col_width = 190 // len(data[0].keys()) if data else 40

    # Header
    for key in data[0].keys():
        pdf.cell(col_width, 10, str(key), border=1)
    pdf.ln()

    # Rows
    for row in data:
        for val in row.values():
            text = str(val)
            if len(text) > 30:
                text = text[:27] + "..."
            pdf.cell(col_width, 10, text, border=1)
        pdf.ln()

    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        pdf.output(tmp.name)
        file_path = tmp.name

    return FileResponse(
        path=file_path,
        filename="rapor.pdf",
        media_type="application/pdf"
    )
