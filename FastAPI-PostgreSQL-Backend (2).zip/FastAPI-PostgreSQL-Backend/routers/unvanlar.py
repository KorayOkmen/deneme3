from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import crud, schemas
from database import get_db

router = APIRouter(
    prefix="/unvanlar",
    tags=["Unvanlar"]
)

@router.get("/", response_model=List[schemas.UnvanOut])
def get_unvanlar(db: Session = Depends(get_db)):
    """
    Tüm aktif unvanları listeler
    """
    return crud.get_unvanlar(db)

@router.post("/", response_model=schemas.UnvanOut)
def create_unvan(payload: schemas.UnvanCreate, db: Session = Depends(get_db)):
    """
    Yeni bir unvan oluşturur
    """
    return crud.create_unvan(db, payload)

@router.put("/{unvan_id}", response_model=schemas.UnvanOut)
def update_unvan(unvan_id: int, payload: schemas.UnvanUpdate, db: Session = Depends(get_db)):
    """
    Var olan bir unvanı günceller
    """
    return crud.update_unvan(db, unvan_id, payload)

@router.delete("/{unvan_id}")
def deactivate_unvan(unvan_id: int, db: Session = Depends(get_db)):
    """
    Unvanı pasif duruma getirir (soft delete)
    """
    return crud.deactivate_unvan(db, unvan_id)
