from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models, schemas

router = APIRouter(prefix="/odeme-vadeleri", tags=["Ödeme Vadeleri"])

@router.get("/", response_model=list[schemas.OdemeVadesiOut])
def list_vadeler(db: Session = Depends(get_db)):
    return db.query(models.OdemeVadesi).all()

@router.post("/", response_model=schemas.OdemeVadesiOut)
def create_vade(item: schemas.OdemeVadesiCreate, db: Session = Depends(get_db)):
    db_item = models.OdemeVadesi(**item.dict())
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item

@router.patch("/{id}", response_model=schemas.OdemeVadesiOut)
def update_vade(id: int, item: schemas.OdemeVadesiUpdate, db: Session = Depends(get_db)):
    db_item = db.query(models.OdemeVadesi).filter(models.OdemeVadesi.id == id).first()
    if not db_item:
        raise HTTPException(status_code=404, detail="Vade bulunamadı")
    for key, value in item.dict(exclude_unset=True).items():
        setattr(db_item, key, value)
    db.commit()
    db.refresh(db_item)
    return db_item
@router.patch("/{id}", response_model=schemas.OdemeVadesiOut)
def update_vade(id: int, item: schemas.OdemeVadesiUpdate, db: Session = Depends(get_db)):
    db_item = db.query(models.OdemeVadesi).filter(models.OdemeVadesi.id == id).first()
    if not db_item:
        raise HTTPException(status_code=404, detail="Vade bulunamadı")

    for key, value in item.dict(exclude_unset=True).items():
        setattr(db_item, key, value)

    db.commit()
    db.refresh(db_item)
    return db_item
@router.delete("/{id}")
def delete_vade(id: int, db: Session = Depends(get_db)):
    vade = db.query(models.OdemeVadesi).filter(models.OdemeVadesi.id == id).first()
    if not vade:
        raise HTTPException(status_code=404, detail="Vade bulunamadı")
    db.delete(vade)
    db.commit()
    return {"detail": "Silindi"}
