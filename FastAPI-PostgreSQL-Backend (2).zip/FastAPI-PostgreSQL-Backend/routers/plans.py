from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, joinedload
from typing import List

import models, schemas
from database import get_db

router = APIRouter()


# === 1. Tüm planları getir (project ilişkisiyle birlikte)
@router.get("/", response_model=List[schemas.PlanOut])
def get_all_plans(db: Session = Depends(get_db)):
    return (
        db.query(models.Plan)
        .options(joinedload(models.Plan.project))
        .order_by(models.Plan.id.desc())
        .all()
    )


# === 2. Plan oluştur
@router.post("/", response_model=schemas.PlanOut, status_code=status.HTTP_201_CREATED)
def create_plan(plan: schemas.PlanCreate, db: Session = Depends(get_db)):
    # İlgili proje var mı kontrol et
    proje = db.query(models.Project).filter(models.Project.id == plan.proje_id).first()
    if not proje:
        raise HTTPException(status_code=404, detail="İlgili proje bulunamadı")
    if proje.tamamlandi:
        raise HTTPException(status_code=400, detail="Tamamlanan projeye plan eklenemez")

    yeni_plan = models.Plan(**plan.dict())
    db.add(yeni_plan)
    db.commit()
    db.refresh(yeni_plan)
    return yeni_plan


# === 3. Tek planı getir (project ilişkisiyle birlikte)
@router.get("/{plan_id}", response_model=schemas.PlanOut)
def get_plan(plan_id: int, db: Session = Depends(get_db)):
    plan = (
        db.query(models.Plan)
        .options(joinedload(models.Plan.project))
        .filter(models.Plan.id == plan_id)
        .first()
    )
    if not plan:
        raise HTTPException(status_code=404, detail="Plan bulunamadı")
    return plan


# === 4. Plan güncelle
@router.put("/{plan_id}", response_model=schemas.PlanOut)
def update_plan(plan_id: int, guncel_veri: schemas.PlanCreate, db: Session = Depends(get_db)):
    plan = db.query(models.Plan).filter(models.Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan bulunamadı")

    for field, value in guncel_veri.dict().items():
        setattr(plan, field, value)

    db.commit()
    db.refresh(plan)
    return plan


# === 5. Plan sil
@router.delete("/{plan_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_plan(plan_id: int, db: Session = Depends(get_db)):
    plan = db.query(models.Plan).filter(models.Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan bulunamadı")

    db.delete(plan)
    db.commit()
