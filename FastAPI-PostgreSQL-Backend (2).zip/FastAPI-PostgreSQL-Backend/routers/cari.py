# routers/cari.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError, DataError
from datetime import date

from database import get_db
import schemas, models
from services.numarator import get_next_number

router = APIRouter(prefix="/cari", tags=["Cari Hesaplar"])


# ===========================
# Yardımcı Fonksiyonlar
# ===========================
def _dump(model):
    """Pydantic v1/v2 uyumlu dict dönüşümü."""
    return model.model_dump() if hasattr(model, "model_dump") else model.dict()

def _to_int_or_none(v):
    """Boş string/null değerleri None yap, varsa integer'a çevir."""
    if v in (None, "", "null"):
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None

def _normalize_bool_str(v: str | None):
    """Boolean string normalizasyonu ('true', 'evet', '0', 'hayır' vb.)."""
    if v is None:
        return None
    v2 = str(v).strip().lower()
    if v2 in ("true", "1", "evet"):
        return True
    if v2 in ("false", "0", "hayir", "hayır"):
        return False
    return None

def _map_hesap_turu(v: str | None) -> str | None:
    """Türkçe/İngilizce karışık girişleri normalize et."""
    if not v:
        return None
    key = v.strip().lower()
    mapping = {
        "musteri": "musteri", "müşteri": "musteri",
        "tedarikci": "tedarikci", "tedarikçi": "tedarikci",
        "potansiyel": "potansiyel",
    }
    return mapping.get(key, key)

def _belge_tipi_for_cari(hesap_turu: str | None) -> str:
    """Hesap türüne göre belge tipini belirle."""
    key = (hesap_turu or "").strip().lower()
    if key in ("musteri", "müşteri"):
        return "Cari Açılışı"
    if key in ("tedarikci", "tedarikçi"):
        return "Tedarikçi Açılışı"
    if key == "potansiyel":
        return "Potansiyel Açılışı"
    return "Cari Açılışı"

def _ensure_int_belge_no(raw_no) -> int:
    """
    Numaratör string döndürebilir (örn. 'CR-2025-000007').
    Bu fonksiyon son sayısal parçayı ayıklar ve int döner.
    """
    if raw_no is None:
        raise HTTPException(status_code=500, detail="Numaratör belge_no üretmedi.")
    if isinstance(raw_no, int):
        return raw_no
    # string ise: son '-' sonrası numeric parçayı al
    try:
        part = str(raw_no).split("-")[-1]
        return int(part)
    except Exception:
        raise HTTPException(status_code=500, detail="Numaratör belge_no formatı geçersiz.")


# ===========================
# Listeleme
# ===========================
@router.get("/", response_model=list[schemas.CariOut])
def list_cariler(
    unvan: str | None = Query(None),
    tur: str | None = Query(None),
    is_active: str | None = Query(None),
    db: Session = Depends(get_db),
):
    q = db.query(models.Cari)

    if unvan and unvan.strip():
        q = q.filter(models.Cari.unvan.ilike(f"%{unvan.strip()}%"))

    tur_norm = _map_hesap_turu(tur)
    if tur_norm:
        q = q.filter(models.Cari.hesap_turu == tur_norm)

    active_norm = _normalize_bool_str(is_active)
    if active_norm is not None:
        q = q.filter(models.Cari.is_active == active_norm)

    return q.all()


# ===========================
# Oluştur
# ===========================
@router.post("/", response_model=schemas.CariOut)
def create_cari(payload: schemas.CariCreate, db: Session = Depends(get_db)):
    data = _dump(payload)

    # Sayısal alanlar normalize
    for k in ("tahsilat_gunu", "tahsilat_vadesi"):
        data[k] = _to_int_or_none(data.get(k))

    # Payload yanlışlıkla belge alanları gönderse bile yok say
    for k in ("belge_tipi", "belge_seri", "belge_no"):
        data.pop(k, None)

    # hesap_turu normalize
    if "hesap_turu" in data:
        data["hesap_turu"] = _map_hesap_turu(data.get("hesap_turu"))

    # hesap_kodu tekillik (doluysa)
    if data.get("hesap_kodu"):
        exists = db.query(models.Cari).filter(models.Cari.hesap_kodu == data["hesap_kodu"]).first()
        if exists:
            raise HTTPException(status_code=400, detail="Bu hesap kodu zaten mevcut!")

    # Belge tipi + numaratör
    belge_tipi = _belge_tipi_for_cari(data.get("hesap_turu"))
    alan_id = data.get("alan_id")

    try:
        num = get_next_number(db, modul="Cari", belge_tipi=belge_tipi, alan_id=alan_id)
        belge_seri = num["belge_seri"]            # örn: "CR"
        belge_no = _ensure_int_belge_no(num["belge_no"])  # int'e zorla

        # Cari kaydı
        obj = models.Cari(
            **data,
            belge_tipi=belge_tipi,
            belge_seri=belge_seri,
            belge_no=belge_no,
        )
        db.add(obj)
        db.flush()  # id almak için

        # Otomatik açılış hareketi
        islem = models.CariIslem(
            cari_id=obj.id,
            hesap_kodu=obj.hesap_kodu,
            tarih=date.today(),
            aciklama=f"{obj.unvan} için otomatik açılış işlemi",
            belge_tipi=belge_tipi,
            belge_seri=belge_seri,
            belge_no=belge_no,
            borc=0,
            alacak=0,
            bakiye=0,
        )
        db.add(islem)

        db.commit()
        db.refresh(obj)
        return obj

    except (IntegrityError, DataError) as db_err:
        db.rollback()
        # Ör: unique ihlali, tip uyumsuzluğu
        raise HTTPException(
            status_code=400,
            detail="Kayıt oluşturulamadı (tekillik veya veri tipi hatası).",
        ) from db_err


# ===========================
# Güncelle
# ===========================
@router.put("/{cari_id}", response_model=schemas.CariOut)
def update_cari(cari_id: int, payload: schemas.CariUpdate, db: Session = Depends(get_db)):
    obj = db.query(models.Cari).filter(models.Cari.id == cari_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Cari hesap bulunamadı")

    data = payload.model_dump(exclude_unset=True) if hasattr(payload, "model_dump") else payload.dict(exclude_unset=True)

    # Sayısal alanlar normalize
    for k in ("tahsilat_gunu", "tahsilat_vadesi"):
        if k in data:
            data[k] = _to_int_or_none(data.get(k))

    # Belge alanları değiştirilemez
    for immutable in ("belge_tipi", "belge_seri", "belge_no"):
        data.pop(immutable, None)

    # hesap_turu normalize
    if "hesap_turu" in data:
        data["hesap_turu"] = _map_hesap_turu(data.get("hesap_turu"))

    # hesap_kodu tekillik kontrolü
    if "hesap_kodu" in data and data["hesap_kodu"] and data["hesap_kodu"] != obj.hesap_kodu:
        exists = db.query(models.Cari).filter(models.Cari.hesap_kodu == data["hesap_kodu"]).first()
        if exists:
            raise HTTPException(status_code=400, detail="Bu hesap kodu zaten mevcut!")

    # Güncelle
    for field, value in data.items():
        setattr(obj, field, value)

    db.commit()
    db.refresh(obj)
    return obj


# ===========================
# Sil
# ===========================
@router.delete("/{cari_id}", status_code=204)
def delete_cari(cari_id: int, db: Session = Depends(get_db)):
    obj = db.query(models.Cari).filter(models.Cari.id == cari_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Cari hesap bulunamadı")

    # FK ilişkileri varsa önce bağlı hareketleri silmek gerekebilir (schema'na göre).
    db.delete(obj)
    db.commit()
    return


# ===========================
# Detay
# ===========================
@router.get("/{cari_id}", response_model=schemas.CariOut)
def get_cari_detail(cari_id: int, db: Session = Depends(get_db)):
    obj = db.query(models.Cari).filter(models.Cari.id == cari_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Cari hesap bulunamadı")
    return obj
