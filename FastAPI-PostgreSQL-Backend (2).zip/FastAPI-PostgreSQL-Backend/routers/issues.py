from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import Optional
import models, schemas
import os
from database import get_db

router = APIRouter(prefix="/issues", tags=["Issues"])

@router.post("/", response_model=schemas.IssueOut)
def create_issue(issue: schemas.IssueCreate, db: Session = Depends(get_db)):
    db_issue = models.Issue(**issue.dict())
    db.add(db_issue)
    db.commit()
    db.refresh(db_issue)
    return db_issue

@router.get("/", response_model=list[schemas.IssueOut])
def get_issues(db: Session = Depends(get_db)):
    return db.query(models.Issue).order_by(models.Issue.created_at.desc()).all()

@router.get("/with-comments")
def get_issues_with_comments(db: Session = Depends(get_db)):
    issues = db.query(models.Issue).order_by(models.Issue.created_at.desc()).all()
    response = []
    for issue in issues:
        comments = db.query(models.Comment).filter(models.Comment.issue_id == issue.id).order_by(models.Comment.created_at).all()
        response.append({
            "id": issue.id,
            "konu": issue.konu,
            "aciklama": issue.aciklama,
            "modul": issue.modul,
            "ilgili": (
                db.query(models.User.full_name)
                .filter(models.User.email == issue.ilgili)
                .scalar()
                or issue.ilgili
            ),
            "durum": issue.durum,
            "oncelik": issue.oncelik,
            "created_at": issue.created_at,
            "comments": [
                {
                    "id": c.id,
                    "text": c.text,
                    "durum": c.durum,
                    "created_at": c.created_at,
                    "has_file": os.path.exists(f"uploaded_files/{c.id}")
                } for c in comments
            ]
        })
    return response

@router.post("/with-file")
def create_issue_with_file(
    konu: str = Form(...),
    aciklama: str = Form(...),
    modul: str = Form(...),
    durum: str = Form("Kayıt Açık"),
    ilgili: Optional[str] = Form(None),  # ✅ Zorunlu değil artık
    oncelik: Optional[str] = Form(None),
    uploaded_file: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    allowed_statuses = [
        "Kayıt Açık", "Kayıt Kapalı", "İnceleniyor", "İşlemde",
        "Beklemede", "Tamamlandı", "Reddedildi", "İptal Edildi"
    ]
    if durum not in allowed_statuses:
        raise HTTPException(status_code=400, detail="Geçersiz durum bilgisi")

    # 🔒 boş string gönderildiyse temizle
    if ilgili == "":
        ilgili = None

    db_issue = models.Issue(
        konu=konu,
        aciklama=aciklama,
        modul=modul,
        durum=durum,
        ilgili=ilgili,
        oncelik=oncelik,
    )
    db.add(db_issue)
    db.commit()
    db.refresh(db_issue)

    if uploaded_file:
        os.makedirs("uploaded_files", exist_ok=True)
        with open(f"uploaded_files/issue_{db_issue.id}", "wb") as buffer:
            buffer.write(uploaded_file.file.read())
        db_issue.has_file = True
        db.commit()

    return db_issue

@router.put("/{issue_id}/status", response_model=dict)
def update_issue_status(issue_id: int, status_data: schemas.IssueUpdateStatus, db: Session = Depends(get_db)):
    issue = db.query(models.Issue).filter(models.Issue.id == issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    issue.durum = status_data.durum
    db.commit()
    return {"message": "Durum güncellendi"}

@router.patch("/{issue_id}", response_model=dict)
def update_issue_assignee(issue_id: int, data: dict, db: Session = Depends(get_db)):
    issue = db.query(models.Issue).filter(models.Issue.id == issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    if "ilgili" in data:
        issue.ilgili = data["ilgili"]
    db.commit()
    db.refresh(issue)
    return {"message": "Görevli güncellendi", "ilgili": issue.ilgili}

@router.delete("/{issue_id}", status_code=204)
def delete_issue(issue_id: int, db: Session = Depends(get_db)):
    issue = db.query(models.Issue).filter(models.Issue.id == issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    db.delete(issue)
    db.commit()
