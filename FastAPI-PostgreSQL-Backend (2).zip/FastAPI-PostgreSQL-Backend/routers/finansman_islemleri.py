# routers/finansman_islemleri.py
# routers/finansman_islemleri.py (en üst)
from __future__ import annotations
from decimal import Decimal, InvalidOperation

from datetime import date
from typing import Any, Dict, Iterable, Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy import and_

import models, schemas
from database import get_db
from services.numarator import get_next_number

router = APIRouter(prefix="/finansman-islemler", tags=["Finansman İşlemleri"])

# =========================
# Sabitler & Yardımcılar
# =========================
HESAP_TIPLERI = {"Kasa", "Banka", "Müşteri", "Tedarikçi", "Genel"}
YON_SET = {"Borç", "Alacak"}

def _ensure(cond: bool, msg: str, status: int = 422):
    if not cond:
        raise HTTPException(status_code=status, detail=msg)

def _borc_alacak(yon: str, tutar: Any) -> Tuple[Any, Any]:
    return (tutar, 0) if yon == "Borç" else (0, tutar)

def _put_if_attr(model_cls: Any, key: str, value: Any, out: Dict[str, Any]):
    """Modelde alan varsa out'a koy."""
    if hasattr(model_cls, key):
        out[key] = value

def _hesap_field_kwargs(model_cls: Any, hesap_kod: str) -> Dict[str, Any]:
    """hesap_kod/hesap_kodu farkı için dinamik eşleme."""
    d: Dict[str, Any] = {}
    if hasattr(model_cls, "hesap_kod"):
        d["hesap_kod"] = hesap_kod
    elif hasattr(model_cls, "hesap_kodu"):
        d["hesap_kodu"] = hesap_kod
    return d

def _ref_fields_kwargs(model_cls: Any, baslik_id: int, madde_id: Optional[int]) -> Dict[str, Any]:
    """
    Bazı tablolarınızda referans alanları olabilir: ref_modul, ref_baslik_id, ref_madde_id.
    Varsa set edilir, yoksa yok sayılır.
    """
    d: Dict[str, Any] = {}
    _put_if_attr(model_cls, "ref_modul", "finansman", d)
    _put_if_attr(model_cls, "ref_baslik_id", baslik_id, d)
    if madde_id is not None:
        _put_if_attr(model_cls, "ref_madde_id", madde_id, d)
    return d

def _common_doc_fields_kwargs(model_cls: Any, baslik: models.FinansmanIslem) -> Dict[str, Any]:
    """
    Belgelerde ortak olan alanları (belge_tipi/seri/no, tarih, aciklama vs.) dinamik set et.
    """
    d: Dict[str, Any] = {}
    _put_if_attr(model_cls, "belge_tipi", baslik.islem_turu, d)
    _put_if_attr(model_cls, "belge_seri", baslik.belge_seri, d)
    _put_if_attr(model_cls, "belge_no", baslik.belge_no, d)
    _put_if_attr(model_cls, "tarih", baslik.tarih, d)
    return d

def _delete_linked_posts(
    db: Session,
    baslik: models.FinansmanIslem,
    madde: Optional[models.FinansmanIslemMadde] = None,
):
    """
    Bağlı muhasebe/kasa/cari hareketlerini sil.
    Önce ref_* alanlarına göre, yoksa belge_seri+belge_no ile temizler.
    """
    targets: Iterable[Any] = []
    # Dinamik import yerine doğrudan models üstünden sınıfları al
    FinansIslem = getattr(models, "FinansIslem", None)
    CariIslem = getattr(models, "CariIslem", None)
    HesapPlaniIslem = getattr(models, "HesapPlaniIslem", None)

    for cls in (FinansIslem, CariIslem, HesapPlaniIslem):
        if cls is None:
            continue

        q = db.query(cls)
        # Öncelik: ref alanları
        if hasattr(cls, "ref_modul") and hasattr(cls, "ref_baslik_id"):
            q = q.filter(cls.ref_modul == "finansman", cls.ref_baslik_id == baslik.id)
            if madde is not None and hasattr(cls, "ref_madde_id"):
                q = q.filter(cls.ref_madde_id == madde.id)
        else:
            # Fallback: belge_seri & belge_no
            preds = []
            if hasattr(cls, "belge_seri"):
                preds.append(cls.belge_seri == baslik.belge_seri)
            if hasattr(cls, "belge_no"):
                preds.append(cls.belge_no == baslik.belge_no)
            if not preds:
                # Hiç eşleşecek alan yoksa bu tabloyu es geç
                continue
            q = q.filter(and_(*preds))

            # Madde özelinde daraltmak istersek hesap_kod ile filtrelemeye çalış
            if madde is not None:
                hf = _hesap_field_kwargs(cls, madde.hesap_kod)
                for k, v in hf.items():
                    q = q.filter(getattr(cls, k) == v)

        # Sil
        q.delete(synchronize_session=False)

# =========================
# 1) Başlık Listeleme
# =========================
@router.get("/", response_model=list[schemas.FinansmanIslemOut])
def list_islemler(
    db: Session = Depends(get_db),
    q: Optional[str] = Query(None, description="Serbest arama (belge_seri, belge_no, aciklama)"),
    islem_turu: Optional[str] = Query(None),
    tarih_from: Optional[date] = Query(None),
    tarih_to: Optional[date] = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    query = db.query(models.FinansmanIslem)
    if islem_turu:
        query = query.filter(models.FinansmanIslem.islem_turu == islem_turu)
    if tarih_from:
        query = query.filter(models.FinansmanIslem.tarih >= tarih_from)
    if tarih_to:
        query = query.filter(models.FinansmanIslem.tarih <= tarih_to)
    if q:
        # Dinamik text alanları—modelde yoksa ignore edilecek
        or_preds = []
        if hasattr(models.FinansmanIslem, "belge_seri"):
            or_preds.append(models.FinansmanIslem.belge_seri.ilike(f"%{q}%"))
        if hasattr(models.FinansmanIslem, "belge_no"):
            or_preds.append(models.FinansmanIslem.belge_no.ilike(f"%{q}%"))
        if hasattr(models.FinansmanIslem, "aciklama"):
            or_preds.append(models.FinansmanIslem.aciklama.ilike(f"%{q}%"))
        if or_preds:
            from sqlalchemy import or_
            query = query.filter(or_(*or_preds))
    return query.order_by(models.FinansmanIslem.id.desc()).offset(offset).limit(limit).all()

# =========================
# 2) Başlık Detay
# =========================
@router.get("/{islem_id}", response_model=schemas.FinansmanIslemOut)
def get_islem(
    islem_id: int = Path(..., ge=1),
    db: Session = Depends(get_db),
):
    islem = db.query(models.FinansmanIslem).filter_by(id=islem_id).first()
    if not islem:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    return islem

# =========================
# 3) Başlık Oluşturma
# =========================
@router.post("/", response_model=schemas.FinansmanIslemOut, status_code=201)
def create_islem(payload: schemas.FinansmanIslemCreate, db: Session = Depends(get_db)):
    num = get_next_number(
        db,
        modul="finansman",
        belge_tipi=payload.islem_turu,          # numaratöre ver
        alan_id=getattr(payload, "alan_id", None),
    )

    # Pydantic v2: model_dump; v1: dict
    data = payload.model_dump(exclude_unset=True) if hasattr(payload, "model_dump") else payload.dict(exclude_unset=True) 
    # ÇAKIŞMA OLMASIN: kur’u ayrıca vermeyeceğiz, belge_tipi zaten modelde yok
    data.pop("belge_tipi", None)  # modelde yok

    islem = models.FinansmanIslem(
        **data,                                  # kur burada zaten var (default 1)
        belge_seri=num.get("belge_seri"),
        belge_no=str(num.get("belge_no")) if num.get("belge_no") is not None else None,
    )
    db.add(islem)
    db.commit()
    db.refresh(islem)
    return islem



# =========================
# 4) Başlık Güncelleme
# =========================
@router.patch("/", response_model=schemas.FinansmanIslemOut)
def update_islem(payload: schemas.FinansmanIslemUpdate, db: Session = Depends(get_db)):
    islem = db.query(models.FinansmanIslem).filter_by(id=payload.id).first()
    if not islem:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")

    # Değişmesini istemediğimiz alanları kilitle (belge_seri/no gibi).
    immutable = {"belge_seri", "belge_no", "id"}
    data = {k: v for k, v in payload.dict().items() if v is not None and k not in immutable}

    for k, v in data.items():
        setattr(islem, k, v)

    db.commit()
    db.refresh(islem)
    return islem

# =========================
# 5) Başlık Silme
# =========================
@router.delete("/{islem_id}", status_code=204)
def delete_islem(islem_id: int, db: Session = Depends(get_db)):
    baslik = db.query(models.FinansmanIslem).filter_by(id=islem_id).first()
    if not baslik:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")

    # Önce bağlı postları sil
    _delete_linked_posts(db, baslik, madde=None)
    # Sonra maddeleri sil (ilişki cascade varsa gerekmez; yine de temkinli)
    db.query(models.FinansmanIslemMadde).filter_by(baslik_id=islem_id).delete(synchronize_session=False)

    db.delete(baslik)
    db.commit()
    return

# =========================
# 6) Madde Listeleme
# =========================
@router.get("/{islem_id}/maddeler", response_model=list[schemas.FinansmanIslemMaddeOut])
def list_maddeler(
    islem_id: int,
    db: Session = Depends(get_db),
    limit: int = Query(500, ge=1, le=5000),
    offset: int = Query(0, ge=0),
):
    _ensure(
        db.query(models.FinansmanIslem).filter_by(id=islem_id).first() is not None,
        "Başlık bulunamadı", 404
    )
    q = db.query(models.FinansmanIslemMadde).filter_by(baslik_id=islem_id)
    return q.order_by(models.FinansmanIslemMadde.id.asc()).offset(offset).limit(limit).all()

# =========================
# 7) Madde Ekleme (+ Otomatik ilgili tabloya kayıt)
# =========================
@router.post("/{islem_id}/maddeler", response_model=schemas.FinansmanIslemMaddeOut, status_code=201)
def add_madde(islem_id: int, payload: schemas.FinansmanIslemMaddeCreate, db: Session = Depends(get_db)):
    baslik = db.query(models.FinansmanIslem).filter_by(id=islem_id).first()
    if not baslik:
        raise HTTPException(status_code=404, detail="Başlık bulunamadı")

    _ensure(payload.hesap_tipi in HESAP_TIPLERI, "Geçersiz hesap_tipi.")
    _ensure(payload.yon in YON_SET, "yon 'Borç' ya da 'Alacak' olmalı.")

    madde = models.FinansmanIslemMadde(baslik_id=islem_id, **payload.dict())
    db.add(madde)
    db.flush()  # madde.id için

    # ---- Otomatik ilgili tabloya kayıt
    borc, alacak = _borc_alacak(payload.yon, payload.tutar)

    if payload.hesap_tipi in {"Kasa", "Banka"}:
        cls = getattr(models, "FinansIslem", None)
    elif payload.hesap_tipi in {"Müşteri", "Tedarikçi"}:
        cls = getattr(models, "CariIslem", None)
    else:
        cls = getattr(models, "HesapPlaniIslem", None)

    if cls is not None:
        kwargs = {}
        kwargs.update(_hesap_field_kwargs(cls, payload.hesap_kod))
        kwargs.update(_common_doc_fields_kwargs(cls, baslik))
        kwargs.update(_ref_fields_kwargs(cls, baslik.id, madde.id))
        _put_if_attr(cls, "aciklama", payload.aciklama, kwargs)
        _put_if_attr(cls, "borc", borc, kwargs)
        _put_if_attr(cls, "alacak", alacak, kwargs)
        _put_if_attr(cls, "doviz_turu", getattr(baslik, "doviz_turu", None), kwargs)   # ✅ doğru alan
        db.add(cls(**kwargs))

    db.commit()
    db.refresh(madde)
    return madde

# =========================
# 8) Madde Güncelleme (+ bağlı hareketi güncelle)
# =========================
@router.patch("/{islem_id}/maddeler/{madde_id}", response_model=schemas.FinansmanIslemMaddeOut)
def update_madde(
    islem_id: int,
    madde_id: int,
    payload: schemas.FinansmanIslemMaddeUpdate,
    db: Session = Depends(get_db),
):
    baslik = db.query(models.FinansmanIslem).filter_by(id=islem_id).first()
    _ensure(baslik is not None, "Başlık bulunamadı", 404)

    madde = db.query(models.FinansmanIslemMadde).filter_by(id=madde_id, baslik_id=islem_id).first()
    _ensure(madde is not None, "Madde bulunamadı", 404)

    data = {k: v for k, v in payload.dict().items() if v is not None}
    if "hesap_tipi" in data:
        _ensure(data["hesap_tipi"] in HESAP_TIPLERI, "Geçersiz hesap_tipi.")
    if "yon" in data:
        _ensure(data["yon"] in YON_SET, "yon 'Borç' ya da 'Alacak' olmalı.")

    # Bağlı hareketleri silip yeniden oluşturmak en güvenlisi
    _delete_linked_posts(db, baslik, madde)

    for k, v in data.items():
        setattr(madde, k, v)

    db.flush()

    # Tekrar post at
    borc, alacak = _borc_alacak(madde.yon, madde.tutar)

    if madde.hesap_tipi in {"Kasa", "Banka"}:
        cls = getattr(models, "FinansIslem", None)
    elif madde.hesap_tipi in {"Müşteri", "Tedarikçi"}:
        cls = getattr(models, "CariIslem", None)
    else:
        cls = getattr(models, "HesapPlaniIslem", None)

    if cls is not None:
        kwargs = {}
        kwargs.update(_hesap_field_kwargs(cls, madde.hesap_kod))
        kwargs.update(_common_doc_fields_kwargs(cls, baslik))
        kwargs.update(_ref_fields_kwargs(cls, baslik.id, madde.id))
        _put_if_attr(cls, "aciklama", madde.aciklama, kwargs)
        _put_if_attr(cls, "borc", borc, kwargs)
        _put_if_attr(cls, "alacak", alacak, kwargs)
        _put_if_attr(cls, "doviz", getattr(baslik, "doviz_turu", None), kwargs)
        db.add(cls(**kwargs))

    db.commit()
    db.refresh(madde)
    return madde

# =========================
# 9) Madde Silme (+ bağlı hareketi sil)
# =========================
@router.delete("/{islem_id}/maddeler/{madde_id}", status_code=204)
def delete_madde(islem_id: int, madde_id: int, db: Session = Depends(get_db)):
    baslik = db.query(models.FinansmanIslem).filter_by(id=islem_id).first()
    _ensure(baslik is not None, "Başlık bulunamadı", 404)

    madde = db.query(models.FinansmanIslemMadde).filter_by(id=madde_id, baslik_id=islem_id).first()
    _ensure(madde is not None, "Madde bulunamadı", 404)

    _delete_linked_posts(db, baslik, madde)
    db.delete(madde)
    db.commit()
    return
