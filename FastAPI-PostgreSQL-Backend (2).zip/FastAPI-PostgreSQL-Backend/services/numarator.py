from datetime import date
from fastapi import HTTPException
from sqlalchemy import and_
from sqlalchemy.orm import Session
from models import BelgeSeri

def get_next_number(
    db: Session,
    *,
    modul: str,
    belge_tipi: str,
    alan_id: int | None = None
):
    """
    Döndürür:
      {
        "belge_seri": "CR",          # seri_kodu
        "belge_no": 7,               # INT -> DB'ye yazılacak sayaç
        "display_no": "CR-2025-000007"  # UI için formatlı gösterim
      }
    Not: transaction içinde çağır (router'da zaten öyle); with_for_update yarışları önler.
    """
    today = date.today()

    # Alan filtre mantığı: alan_id None ise NULL eşle
    q = (
        db.query(BelgeSeri)
          .filter(
              BelgeSeri.modul == modul,
              BelgeSeri.belge_tipi == belge_tipi,
              (BelgeSeri.alan_id == alan_id) if alan_id is not None else BelgeSeri.alan_id.is_(None),
              BelgeSeri.aktif.is_(True),
          )
          .with_for_update()
    )
    seri = q.first()
    if not seri:
        raise HTTPException(status_code=400, detail="Belge serisi tanımlı değil.")

    # Validasyonlar
    if not seri.seri_kodu or len(seri.seri_kodu) != 2:
        raise HTTPException(status_code=400, detail="Seri kodu 2 haneli olmalı.")
    if not isinstance(seri.pad_length, int) or seri.pad_length <= 0:
        raise HTTPException(status_code=400, detail="pad_length pozitif bir tamsayı olmalı.")

    # İlk kurulumda yıl/ay alanları None olabilir; bugünü baz al
    if seri.son_yil is None:
        seri.son_yil = today.year
    if seri.ay_bazli and seri.son_ay is None:
        seri.son_ay = today.month

    # Yıl/Ay bazlı reset
    reset = False
    if seri.yil_bazli and seri.son_yil != today.year:
        reset = True
    if seri.ay_bazli and (seri.son_yil != today.year or seri.son_ay != today.month):
        reset = True
    if reset:
        seri.sayac = 0
        seri.son_yil = today.year
        seri.son_ay = today.month if seri.ay_bazli else seri.son_ay

    # Sayaç arttır
    seri.sayac = (seri.sayac or 0) + 1
    next_no = int(seri.sayac)  # <- DB’ye yazılacak INTEGER

    # Formatlı çekirdek (örn. 000007)
    core = str(next_no).zfill(seri.pad_length)

    # Display parçaları
    parts = []
    if seri.prefix:
        parts.append(seri.prefix)
    parts.append(seri.seri_kodu)           # "CR"
    if seri.yil_bazli:
        parts.append(str(today.year))      # "2025"
    if seri.ay_bazli:
        parts.append(f"{today.month:02}")  # "08"
    parts.append(core)                     # "000007"
    if seri.suffix:
        parts.append(seri.suffix)

    display_no = "-".join(parts)

    # Persist seri değişiklikleri
    db.add(seri)
    db.flush()  # kilit altında sayaç güncellendi

    return {
    "belge_seri": seri.seri_kodu,
    "belge_no": next_no,        # INT
    "full_no": display_no,      # 👈 Burada artık full_no döndürüyoruz
    }
