# -*- coding: utf-8 -*-
from __future__ import annotations
from decimal import Decimal
from sqlalchemy.orm import Session
from models_finance import FinansBelge, FinansBelgeMadde, GLEntry, GLLine

def post_belge(db: Session, belge_id: int) -> int:
    belge: FinansBelge = db.query(FinansBelge).get(belge_id)
    if not belge:
        raise ValueError("Belge bulunamadı")
    if belge.durum not in ("approved", "posted", "reversed"):
        # draft -> approved -> posted; ister direkt posted’a da izin verebilirsin
        belge.durum = "approved"

    # Toplam kontrolü (double-entry)
    toplam_borc = sum((m.borc or 0) for m in belge.maddeler)
    toplam_alacak = sum((m.alacak or 0) for m in belge.maddeler)
    if round(float(toplam_borc - toplam_alacak), 2) != 0:
        raise ValueError("Belge madde toplamları eşit değil (double-entry)!")

    gl = GLEntry(belge_id=belge.id, period=belge.tarih.strftime("%Y-%m"))
    db.add(gl); db.flush()

    for m in belge.maddeler:
        db.add(GLLine(
            gl_entry_id=gl.id,
            hesap_plani_id=m.hesap_plani_id,
            cari_id=m.cari_id, kasa_id=m.kasa_id, banka_id=m.banka_id,
            borc=m.borc, alacak=m.alacak,
            doviz_tutar=m.doviz_tutar, kur=m.kur, yerel_tutar=m.yerel_tutar,
            aciklama=m.aciklama or belge.aciklama,
        ))

    belge.durum = "posted"
    belge.toplam_borc = toplam_borc
    belge.toplam_alacak = toplam_alacak

    db.commit()
    return gl.id
